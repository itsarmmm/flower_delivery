import os


# MAIN CONST
DEBUG = True   # True - включить дебаггинг (все процессы и ошибки в консоль)
MAIN_ADMIN_LIST = ["1192482814","520491634","1651383143"]
AUTOMATIC_ADD_ADMIN = []

# MAIN BOT SETTINGS
DB_URL = os.getenv('DATABASE_URL', "postgres://postgres:postgres@localhost:5432/") 
REDIS_URL = os.getenv('REDIS_URL',"redis://root:flowdeltest@redis-19495.c283.us-east-1-4.ec2.cloud.redislabs.com:19495/0")
REDIS_FSM = os.getenv("DOKKU_REDIS_AQUA_URL","redis://flowdel_fsm:1db7129ff8c4bb95bf7a71e0fce06205c9c0ae3d6ca339f045ec9848f619228b@wat-studio.com:2411")

DOMEN_HOST = "https://flowdel.wat-studio.com/"
PAY_TOKEN = "381764678:TEST:22680"
QIWI_P2P_TOKEN = "eyJ2ZXJzaW9uIjoiUDJQIiwiZGF0YSI6eyJwYXlpbl9tZXJjaGFudF9zaXRlX3VpZCI6InU3NTEyOS0wMCIsInVzZXJfaWQiOiI3OTE1NDE0MjE5MiIsInNlY3JldCI6IjU0MTBlNWEwNTM3MGY2ZGYyNzllYjczNWFlMjk5Yzg4NzY0YjljZWM1MWY5ODAxYjg1MjczZTUwODU0NTZlYzMifX0="
QIWI_PHONE = "79154142192"
TOKEN = "TOKEN"
CURRIER_BOT_TOKEN = "1646880505:AAH_Zp8Zuo0Y9Ss47DRhJYtFM6j6cq7wIbo" 
MODER_CURRIER_CHANNEL = "-1001262907808" 
ORDER_CURRIER_CHANNEL = "-1001446871314" 
PAYMENTS_PROVIDER_TOKEN = 'TOKEN'


# SMS SETTINGS
SMS_TOKEN = "dLkLWntkyoDip1BGasdX1VhKAXY"
SMS_PASSWORD = "G4508160b$"
SMS_EMAIL  = "investor@list.ru"
SMS_TEMPLATES = "Код для подтверждения аккаунта в боте доставки цветов: {}"




# ORDER STATUS



ORDER_WAIT_STATUS = [
        "searthCurrier_nal",
        "searthCurrier_online",
        "searthCurrier_balans"
]




CURRIER_ACTIVE_STATUS = [
	"getedCurrier",
	"waitCurrierDelivery"
]


CUSTOMER_ACTIVE_STATUS = [
		"getedCurrier",
        "searthCurrier",
        "waitCurrierDelivery"

]




