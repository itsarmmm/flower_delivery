from fsm import FSM,RedisFSM
from base import Base
from smsaero import SmsAero
from telebot import TeleBot
from flask import Flask
from redisworks import Root
from qiwi_sdk import QiwiPay
import config
import redis


# DATABASE
#fsm_base = Base(config.DB_URL)
base = Base(config.DB_URL)
#redis_connector = redis.from_url(config.REDIS_URL)
redis_connector = Root(create_from_url=config.REDIS_URL)
fsm_base = Root(create_from_url=config.REDIS_FSM)


# APP
bot = TeleBot(config.TOKEN)
cur_bot = TeleBot(config.CURRIER_BOT_TOKEN)
app =  Flask(__name__)
app.config['TEMPLATES_AUTO_RELOAD'] = True
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0

#fsm = FSM(fsm_base)
fsm = RedisFSM(fsm_base)

sms_api = SmsAero(config.SMS_EMAIL,config.SMS_PASSWORD)

qiwi_pay = QiwiPay(False,config.QIWI_PHONE,p2p_key=config.QIWI_P2P_TOKEN,username=False)