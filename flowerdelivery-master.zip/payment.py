from telebot.types import LabeledPrice




class PayController:
    def __init__(self,bot,pay_token):
        self.bot = bot
        self.price = []
        self.pay_token = pay_token
        self.provider_data = False

    def add_price(self,label,amount):
        new_price = LabeledPrice(label=label, amount=amount)
        self.price.append(new_price) 

    def create_invoice(self,chat_id,title,description,invoice_payload,need_name=True,need_phone_number=True,reply_markup=False):
        self.bot.send_invoice(chat_id=chat_id, title=title,
                description=description,
                invoice_payload=invoice_payload,
                provider_token=self.pay_token,
                currency='rub',
                prices=self.price,
                start_parameter='payment',
                need_name=need_name,
                need_phone_number=need_phone_number,
                provider_data=self.provider_data,
                reply_markup=reply_markup)    