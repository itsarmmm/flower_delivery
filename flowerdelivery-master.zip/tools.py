import json
import re


def split_list(arr, wanted_parts=1):
    """Разбить список на подсписки"""
    arrs = []
    while len(arr) > wanted_parts:
        pice = arr[:wanted_parts]
        arrs.append(pice)
        arr = arr[wanted_parts:]
    arrs.append(arr)
    return arrs




def validate_email(email):
    """Валидация email"""  
    if(re.search('^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w{2,3}$',email)):  
        return True
    return False



