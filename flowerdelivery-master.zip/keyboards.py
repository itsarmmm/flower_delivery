import bot_utils as  tools
import telebot




# ----Получить клавиатуру главного меню----
def get_main_menu(language):
	text = language["main_menu"]
	markup = [
		[text[0],text[1]],
		[text[2],text[3]]
		]
	return tools.create_reply_from_matrix(markup)




def get_main_menu_section(language,key_list,row=0):
	"""Создать новую репли секцию в главном меню"""
	markup = list(key_list)
	markup.append(language["back_to_main_menu"])
	return tools.create_markup(markup,row=row)



# ----Меню заказов из главного меню----
def get_main_order_menu(language):
	return get_main_menu_section(language,language["reply_markups"]["main_menu_order_section"],row=2)



def get_main_menu_currier_menu(language):
	return tools.create_markup(language["reply_markups"]["main_menu_start_as_currier"],row=2)





def get_admin_panel(language):
	markup = {
		"Рассылка":"admin_mass_send_menu",
		"Заблокировать курьера":"block_currier_menu",
		"Заблокировать клиента":"block_client_menu"
		}
	return tools.create_inlineKeyboard(markup)