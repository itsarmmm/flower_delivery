import psycopg2



def gen_where(data:dict,like_prefix=[]):
    sql = ""
    values = list(data.values())
    for i in data:
        do_prefix = "="
        if str(i) in like_prefix:
            do_prefix = "LIKE"
        sql += "{} {} %s".format(i,do_prefix)
        if list(data.keys()).index(i) != (len(data) - 1):
            sql += " AND "

    return (sql,values)



class Base:
    def __init__(self,db_url):
        self.db_url = db_url
        #self.connection = psycopg2.connect(db_url)
        #self.cursor = self.connection.cursor()


    def insert(self,table: str,data: dict,return_id=False):
        columns = ', '.join( data.keys())
        values = list(data.values())
        placeholders = ", ".join(['%s' for i in range(len(data.keys()))])
        sql = f"INSERT INTO {table} ({columns}) VALUES ({placeholders})"
        if return_id:
            sql += " RETURNING id;"

        connection = psycopg2.connect(self.db_url)
        cursor = connection.cursor()
        cursor_used = cursor.execute(sql,values)
        connection.commit()
        
        if return_id:
            data_to_return = cursor.fetchone()[0]
            connection.close()
            return data_to_return
        connection.close()
        return False

    
    def select(self,table: str,columns: list):
        columns_joined = ",".join(columns)
        connection = psycopg2.connect(self.db_url)
        cursor = connection.cursor()
        cursor.execute(f"SELECT ({columns_joined}) FROM {table}")
        data_to_return = cursor.fetchall()
        connection.close()
        return data_to_return

    def select_all(self,table: str):
        connection = psycopg2.connect(self.db_url)
        cursor = connection.cursor()
        cursor.execute(f"SELECT * FROM {table}")
        data_to_return = cursor.fetchall()
        connection.close()
        return data_to_return
    
    def select_where(self,table: str,data: dict,col=[],custom_col=False,like_prefix=[]):
        columns = "*"
        if custom_col:
            columns = custom_col
        data_to = gen_where(data,like_prefix=like_prefix)
        if len(col) != 0:
            columns = "(" + ",".join(columns) + ")"
        sql = "SELECT {} FROM {} WHERE {}".format(columns,table,data_to[0])
        if len(data) == 0:
            return False
        connection = psycopg2.connect(self.db_url)
        cursor = connection.cursor()        
        cursor.execute(sql,data_to[1])
        data_to_return = cursor.fetchall()
        connection.close()
        return data_to_return

    def select_one(self,table: str,like_prefix=[],**args):
        all = self.select_where(table,args,like_prefix=like_prefix)
        if all:
            return all[0]
        return False

    def test(self,table: str,**args):
        if self.select_one(table,**args):
            return True
        return False

    def delete(self,table: str,**args):
        if len(args) == 0:
            return
        data_to = gen_where(args)
        sql = "DELETE FROM {} WHERE {}".format(table,data_to[0])
        connection = psycopg2.connect(self.db_url)
        cursor = connection.cursor()        
        cursor.execute(sql,data_to[1])
        connection.commit()
        connection.close()

    def delete_all(self,*args):
        if len(args) == 0:
            return False
        sql = "TRUNCATE "
        for table in args:
            sql += str(table)
            if table != args[-1]:
                sql += ","
        connection = psycopg2.connect(self.db_url)
        cursor = connection.cursor()        
        cursor.execute(sql)
        connection.commit()    
        connection.close()

    def update(self,table: str,in_map: dict,**args):
        map_args = list(in_map.values())
        set_map = ""
        sql = f"UPDATE {table} SET "
        for i in in_map:
            sql += f"{i} = %s"
            if len(in_map) > 1 and list(in_map.keys()).index(i) != len(in_map) - 1:
                sql += ", "

        if len(args) > 0:
            data_to = gen_where(args)
            sql += f" WHERE {data_to[0]}"
            map_args = map_args + data_to[1]
        connection = psycopg2.connect(self.db_url)
        cursor = connection.cursor()
        cursor.execute(sql,map_args)
        connection.commit()
        connection.close()

    def get_cursor(self):
        connection = psycopg2.connect(self.db_url)
        cursor = connection.cursor()
        return cursor

    def to_binary(self,data):
        return psycopg2.Binary(data)

    def custom_sql(self,sql,args=False):
        connection = psycopg2.connect(self.db_url)
        cursor = connection.cursor()
        if args:
            cursor.execute(sql,args)
        else:
            cursor.execute(sql)
        self.connection.commit()
        self.connection.close()


    def init_db(self):
        with open("create_db.sql", "r") as f:
            sql = f.read()
        connection = psycopg2.connect(self.db_url)
        cursor = connection.cursor()
        cursor.execute(sql)
        connection.commit()
        connection.close()
