import telebot
from tools import split_list
from datetime import datetime



def create_inlineKeyboard(key,row=0,url_mode=False): 
    """Создать инлайн клавиатуру из словаря"""
    keyboard = telebot.types.InlineKeyboardMarkup()

    if row == 0:
        for i in key:
            c = key.get(i)
            if url_mode:
                keyboard.add(telebot.types.InlineKeyboardButton(text=i, url=c))
            else:
                keyboard.add(telebot.types.InlineKeyboardButton(text=i, callback_data=c))
    else:
        key_list = []
        
        for i in key:
            c = key.get(i)
            if url_mode:
                keyboard.add(telebot.types.InlineKeyboardButton(text=i, url=c))
            else:
                key_list.append(telebot.types.InlineKeyboardButton(text=i, callback_data=c))        
        
        for i in split_list(key_list,row):
            keyboard.add(*[name for name in i])

    return keyboard



def create_inline_from_maplist(key_list):
    """Создать инлайн клавиатуру из списка словарей"""
    keyboard = telebot.types.InlineKeyboardMarkup()
    for key_map in key_list:
        all = []
        for key in key_map:
            all.append(telebot.types.InlineKeyboardButton(text=key, callback_data=key_map[key]))
        keyboard.add(*all)
    return keyboard





def create_markup(key, row=0):
    """Создать репли клавиатуру из списка"""
    user_markup = telebot.types.ReplyKeyboardMarkup(True)
    if row == 0:
        for i in key:
            user_markup.add(i)
    else:
        key_list = key
        for i in split_list(key_list, row):
            user_markup.add(*[telebot.types.KeyboardButton(name)
                              for name in i])
    return user_markup

def create_reply_from_matrix(k_list):
    """Создать клавиатуру со списка списков"""
    user_markup = telebot.types.ReplyKeyboardMarkup(True)
    for row in k_list:
        if isinstance(row,list):
                user_markup.add(*row)
        else:
            user_markup.add(str(row))

    return user_markup




def create_from_list(text_list,prefix,row=0):
    """Создать Inline со списка"""
    c = 0
    markup = {}
    for text in text_list:
        markup[text] = "{} {}".format(prefix,c)
        c += 1
    return create_inlineKeyboard(markup,row=row)



def log(func):
    """Логирование обновлений на хендлерах"""
    def wrapper(*args, **kwargs):
        message = args[0]
        print("\n ---------")
        print(datetime.now())
        if str(type(message)) == "<class 'telebot.types.Message'>":
            print("From: %s %s. (id: %s)\nText: %s"%(message.from_user.first_name,message.from_user.last_name,message.from_user.id,message.text))
        elif str(type(message)) == "<class 'telebot.types.CallbackQuery'>":
            print("From: %s %s. (id: %s)\ncallback: %s"%(message.from_user.first_name,message.from_user.last_name,message.from_user.id,message.data))
        return_value = func(*args, **kwargs)
        return return_value
    return wrapper




def send_new_order_to_channel(send_bot,language,order_data,c_id):
    """Отправить заказ в канал"""
    go_adress_data = ""
    num = 1
    for iter_adress in order_data.go_data:
        add_iter = "\n{}) {} - {}".format(num,iter_adress.location,iter_adress.time)
        go_adress_data += add_iter
        num += 1
    temp_text = "-"
    if order_data.taiming_mode:
        temp_text = "+"
    text = language["currier_menu"]["new_order_format"].format(order_data.id,order_data.get_location,order_data.get_time,go_adress_data,temp_text,order_data.currier_display_price)
    markup = {language["currier_menu"]["new_order_markup"]:"accept_order {}".format(order_data.id)}
    send_bot.send_message(c_id,text,reply_markup=create_inlineKeyboard(markup))




