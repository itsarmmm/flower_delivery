CREATE TABLE bot_user (user_id INTEGER PRIMARY KEY,language TEXT,username TEXT,balans INTEGER);


CREATE TABLE order_base (id SERIAL PRIMARY KEY,user_id INTEGER REFERENCES bot_user(user_id),state TEXT,get_location TEXT,owner_phone TEXT,owner_name TEXT,get_time TEXT,go_data BYTEA,price REAL,garant boolean,packed_price REAL,taiming_mode boolean,comment TEXT,edit_text TEXT,currier_id INTEGER,currier_display_price REAL);


CREATE TABLE save_adress_base (id SERIAL PRIMARY KEY,user_id INTEGER REFERENCES bot_user(user_id),name TEXT,get_location TEXT,owner_phone TEXT,owner_name TEXT);
CREATE TABLE admin_list(user_id INTEGER);



CREATE TABLE user_state(user_id INTEGER REFERENCES bot_user(user_id),state TEXT,args bytea);
CREATE TABLE currier_base(user_id INTEGER REFERENCES bot_user(user_id),accept_state boolean,name TEXT,move_type TEXT,birthday TEXT,email TEXT,passport TEXT,selfie TEXT,drive_front TEXT,drive_back TEXT,snils TEXT,bank TEXT,bik TEXT,korespond_amount TEXT,raz_amount TEXT,inn TEXT,phone TEXT,debt_balans REAL,income_balans REAL);



CREATE TABLE payments_history(user_id INTEGER REFERENCES bot_user(user_id),amount REAL,do_name TEXT);


CREATE TABLE block_user(user_id INTEGER PRIMARY KEY );
CREATE TABLE block_currier(user_id INTEGER);





