from app import base,fsm,qiwi_pay
from app import bot as servis_bot
from app import cur_bot as bot
from bot_utils import log
from bot_middleware import language_check,send_confrim_code,to_base_binary_data,get_order_by_data,send_sms,generate_hash
from tools import validate_email
import bot_utils as tools
import keyboards as menu
import telebot
import config
import bot_models




@bot.message_handler(func=lambda message: True and base.test("block_currier",user_id=int(message.from_user.id)))
def block_skip(message):
    pass



# ----Обработка команды /start (первое сообщения юзера)----
@bot.message_handler(commands=['start'])
@log
def start_update(message):
    if not base.test("bot_user",user_id=int(message.from_user.id)):
        base.insert("bot_user",{"user_id":int(message.from_user.id),"language":"ru","username":str(message.from_user.username),"balans":0})
    language = language_check(message.from_user.id)
    if base.test("currier_base",user_id=int(message.from_user.id)):
        markup = tools.create_markup(language["currier_menu"]["menu"],row=2)
        bot.send_message(message.chat.id,language["new_currier_menu"]["currier_welcome"],reply_markup=markup)
    else:
        bot.send_message(message.chat.id,language["reply_markups"]["main_menu_start_as_currier_text"],reply_markup=menu.get_main_menu_currier_menu(language))



#####################--Стать курьером--################################################



# ----Стать курьером-ифно----
@bot.message_handler(func=lambda message: True and message.text == language_check(message.from_user.id)["reply_markups"]["main_menu_start_as_currier"][1])
def start_as_currier_info_update(message):
    language = language_check(message.from_user.id)
    bot.send_message(message.chat.id,language["new_currier_menu"]["info"])


# ----Стать курьером-Регистрация----
@bot.message_handler(func=lambda message: True and message.text == language_check(message.from_user.id)["reply_markups"]["main_menu_start_as_currier"][0])
def start_as_currier_start_reg_update(message):
    language = language_check(message.from_user.id)
    if base.test("currier_base",user_id=int(message.from_user.id)):
        bot.send_message(message.chat.id,language["new_currier_menu"]["already_currier"])
        return
    markup = tools.create_inlineKeyboard({language["new_currier_menu"]["offerta_confrim_but"]:"new_currier_accept_offerta", \
        language["cancel_hundler_but"]:"cancel_hundler"})
    bot.send_message(message.chat.id,language["new_currier_menu"]["offerta_text"],reply_markup=markup)



# ----Принять офферту нового курьера----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split(" ")[0]) == "new_currier_accept_offerta")
@log
def start_as_currier_accept_offerta_update(call):
    language = language_check(call.from_user.id)
    markup = {
        language["new_currier_menu"]["register_steps"]["get_move_type_menu"][0]:"new_currier_select_move r",
        language["new_currier_menu"]["register_steps"]["get_move_type_menu"][1]:"new_currier_select_move rc",
        language["new_currier_menu"]["register_steps"]["get_move_type_menu"][2]:"new_currier_select_move c",
        language["cancel_hundler_but"]:"cancel_hundler"}
    bot.edit_message_reply_markup(chat_id=call.message.chat.id,message_id=call.message.message_id,reply_markup=False)
    bot.reply_to(call.message,str(language["new_currier_menu"]["offerta_ok"]))
    bot.send_message(call.message.chat.id,language["new_currier_menu"]["register_steps"]["get_move_type_text"],reply_markup=tools.create_inlineKeyboard(markup))


# ----Выбор типа метода передвижения нового курьера----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split(" ")[0]) == "new_currier_select_move")
@log
def start_as_currier_select_move_type_update(call):
    language = language_check(call.from_user.id)
    move_type = str(call.data.split(" ")[1])
    if move_type != "r":
        markup = {
            language["new_currier_menu"]["register_steps"]["get_move_type_car_menu"][0]:"new_currier_select_car {}_s".format(move_type),
            language["new_currier_menu"]["register_steps"]["get_move_type_car_menu"][1]:"new_currier_select_car {}_f".format(move_type),
            language["cancel_hundler_but"]:"cancel_hundler"}
        bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=language["new_currier_menu"]["register_steps"]["get_move_type_car_text"],reply_markup=tools.create_inlineKeyboard(markup))
    else:
        markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
        move_type = str(move_type) + "_" + "n"
        bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=language["new_currier_menu"]["register_steps"]["get_name"],reply_markup=markup)
        fsm.set_state(call.message.chat.id,"currier_reg_get_name",move_type=move_type)


# ----Выбор тип трапнспорта нового курьера----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split(" ")[0]) == "new_currier_select_car")
@log
def start_as_currier_select_car_type_update(call):
    language = language_check(call.from_user.id)
    move_type = str(call.data.split(" ")[1])
    markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
    bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=language["new_currier_menu"]["register_steps"]["get_name"],reply_markup=markup)
    fsm.set_state(call.message.chat.id,"currier_reg_get_name",move_type=move_type)



# ----Получить имя нового курьера----
@bot.message_handler(func=lambda message: fsm.get_state(message.from_user.id).state == "currier_reg_get_name")
@log
def start_as_currier_get_name_update(message):
    language = language_check(message.from_user.id)
    markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
    args = fsm.get_state(message.from_user.id).args
    if len(str(message.text).split(" ")) < 3:
        bot.send_message(message.chat.id,language["new_currier_menu"]["register_steps"]["names_error"],reply_markup=markup)
        return
    bot.send_message(message.chat.id,language["new_currier_menu"]["register_steps"]["get_birthday"],reply_markup=markup)
    fsm.set_state(message.chat.id,"currier_reg_get_birthday",move_type=args.move_type,name=str(message.text))


# ----Получить дату рождения нового курьера----
@bot.message_handler(func=lambda message: fsm.get_state(message.from_user.id).state == "currier_reg_get_birthday")
@log
def start_as_currier_get_birthday_update(message):
    language = language_check(message.from_user.id)
    args = fsm.get_state(message.from_user.id).args
    markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
    if len(str(message.text).split(".")) != 3:
        bot.send_message(message.chat.id,language["new_currier_menu"]["register_steps"]["birthday_error"],reply_markup=markup)
        return
    bot.send_message(message.chat.id,language["new_currier_menu"]["register_steps"]["get_email"],reply_markup=markup)
    fsm.set_state(message.chat.id,"currier_reg_get_email",move_type=args.move_type,name=args.name,birthday=str(message.text))




# ----Получить почту нового курьера----
@bot.message_handler(func=lambda message: fsm.get_state(message.from_user.id).state == "currier_reg_get_email")
@log
def start_as_currier_get_email_update(message):
    language = language_check(message.from_user.id)
    args = fsm.get_state(message.from_user.id).args
    markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
    if not validate_email(str(message.text)):
        bot.send_message(message.chat.id,language["new_currier_menu"]["register_steps"]["email_error"],reply_markup=markup)
        return
    bot.send_message(message.chat.id,language["new_currier_menu"]["register_steps"]["get_passport"],reply_markup=markup)
    fsm.set_state(message.chat.id,"currier_reg_get_passport",move_type=args.move_type,name=args.name,birthday=args.birthday,email=str(message.text))



# ----Получить паспорт нового курьера----
@bot.message_handler(content_types=['location','video', 'document', 'audio', 'voice', 'photo', 'text'],func=lambda message: fsm.get_state(message.from_user.id).state == "currier_reg_get_passport")
@log
def start_as_currier_get_passport_update(message):
    language = language_check(message.from_user.id)
    args = fsm.get_state(message.from_user.id).args
    markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
    if str(message.content_type) != "photo":
        bot.send_message(message.chat.id,language["new_currier_menu"]["register_steps"]["need_photo_error"],reply_markup=markup)
        return
    file_id = str(message.photo[0].file_id)
    bot.send_message(message.chat.id,language["new_currier_menu"]["register_steps"]["get_selfie"],reply_markup=markup)
    fsm.set_state(message.chat.id,"currier_reg_get_selfie",move_type=args.move_type,name=args.name,birthday=args.birthday,email=args.email,passport=file_id)



# ----Получить селфи нового курьера----
@bot.message_handler(content_types=['location','video', 'document', 'audio', 'voice', 'photo', 'text'],func=lambda message: fsm.get_state(message.from_user.id).state == "currier_reg_get_selfie")
@log
def start_as_currier_get_selfie_update(message):
    language = language_check(message.from_user.id)
    args = fsm.get_state(message.from_user.id).args
    markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
    if str(message.content_type) != "photo":
        bot.send_message(message.chat.id,language["new_currier_menu"]["register_steps"]["need_photo_error"],reply_markup=markup)
        return
    file_id = str(message.photo[0].file_id)
    new_state = "currier_reg_get_snils"
    new_text = "get_snils"
    if str(args.move_type).split("_")[0] != "r":
        new_state = "currier_reg_get_front_drive"
        new_text = "get_drive_license_front"
    bot.send_message(message.chat.id,language["new_currier_menu"]["register_steps"][new_text],reply_markup=markup)
    fsm.set_state(message.chat.id,new_state,move_type=args.move_type,name=args.name,birthday=args.birthday,email=args.email,passport=args.passport,selfie=file_id,drive_front=False,drive_back=False)


# ----Получить переднюю сторону прав нового курьера----
@bot.message_handler(content_types=['location','video', 'document', 'audio', 'voice', 'photo', 'text'],func=lambda message: fsm.get_state(message.from_user.id).state == "currier_reg_get_front_drive")
@log
def start_as_currier_get_front_drive_update(message):
    language = language_check(message.from_user.id)
    args = fsm.get_state(message.from_user.id).args
    markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
    if str(message.content_type) != "photo":
        bot.send_message(message.chat.id,language["new_currier_menu"]["register_steps"]["need_photo_error"],reply_markup=markup)
        return
    file_id = str(message.photo[0].file_id)
    bot.send_message(message.chat.id,language["new_currier_menu"]["register_steps"]["get_drive_license_back"],reply_markup=markup)
    fsm.set_state(message.chat.id,"currier_reg_get_back_drive",move_type=args.move_type,name=args.name,birthday=args.birthday,email=args.email,passport=args.passport,selfie=args.selfie,drive_front=file_id)   


# ----Получить заднюю сторону прав нового курьера----
@bot.message_handler(content_types=['location','video', 'document', 'audio', 'voice', 'photo', 'text'],func=lambda message: fsm.get_state(message.from_user.id).state == "currier_reg_get_back_drive")
@log
def start_as_currier_get_back_drive_update(message):
    language = language_check(message.from_user.id)
    args = fsm.get_state(message.from_user.id).args
    markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
    if str(message.content_type) != "photo":
        bot.send_message(message.chat.id,language["new_currier_menu"]["register_steps"]["need_photo_error"],reply_markup=markup)
        return
    file_id = str(message.photo[0].file_id)
    bot.send_message(message.chat.id,language["new_currier_menu"]["register_steps"]["get_snils"],reply_markup=markup)
    fsm.set_state(message.chat.id,"currier_reg_get_snils",move_type=args.move_type,name=args.name,birthday=args.birthday,email=args.email,passport=args.passport,selfie=args.selfie,drive_front=args.drive_front,drive_back=file_id)




# ----Получить СНИЛС нового курьера----
@bot.message_handler(func=lambda message: fsm.get_state(message.from_user.id).state == "currier_reg_get_snils")
@log
def start_as_currier_get_snils_update(message):
    language = language_check(message.from_user.id)
    args = fsm.get_state(message.from_user.id).args
    markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
    bot.send_message(message.chat.id,language["new_currier_menu"]["register_steps"]["get_bank"],reply_markup=markup)
    fsm.set_state(message.chat.id,"currier_reg_get_bank",move_type=args.move_type,name=args.name,birthday=args.birthday,email=args.email,passport=args.passport,selfie=args.selfie,drive_front=args.drive_front,drive_back=args.drive_back,snils=str(message.text)) 



# ----Получить банк нового курьера----
@bot.message_handler(func=lambda message: fsm.get_state(message.from_user.id).state == "currier_reg_get_bank")
@log
def start_as_currier_get_bank_update(message):
    language = language_check(message.from_user.id)
    args = fsm.get_state(message.from_user.id).args
    markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
    bot.send_message(message.chat.id,language["new_currier_menu"]["register_steps"]["get_bik"],reply_markup=markup)
    fsm.set_state(message.chat.id,"currier_reg_get_bik",move_type=args.move_type,name=args.name,birthday=args.birthday,email=args.email, \
        passport=args.passport,selfie=args.selfie,drive_front=args.drive_front,drive_back=args.drive_back,\
        snils=args.snils,bank=str(message.text))



# ----Получить BIK нового курьера----
@bot.message_handler(func=lambda message: fsm.get_state(message.from_user.id).state == "currier_reg_get_bik")
@log
def start_as_currier_get_bik_update(message):
    language = language_check(message.from_user.id)
    args = fsm.get_state(message.from_user.id).args
    markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
    bot.send_message(message.chat.id,language["new_currier_menu"]["register_steps"]["get_korespond_amount"],reply_markup=markup)
    fsm.set_state(message.chat.id,"currier_reg_get_korespond_amount",move_type=args.move_type,name=args.name,birthday=args.birthday,email=args.email, \
        passport=args.passport,selfie=args.selfie,drive_front=args.drive_front,drive_back=args.drive_back,\
        snils=args.snils,bank=args.bank,bik=str(message.text))


# ----Получить кореспонденский счёт нового курьера----
@bot.message_handler(func=lambda message: fsm.get_state(message.from_user.id).state == "currier_reg_get_korespond_amount")
@log
def start_as_currier_get_korespondent_update(message):
    language = language_check(message.from_user.id)
    args = fsm.get_state(message.from_user.id).args
    markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
    bot.send_message(message.chat.id,language["new_currier_menu"]["register_steps"]["get_razamount"],reply_markup=markup)
    fsm.set_state(message.chat.id,"currier_reg_get_raz_amount",move_type=args.move_type,name=args.name,birthday=args.birthday,email=args.email, \
        passport=args.passport,selfie=args.selfie,drive_front=args.drive_front,drive_back=args.drive_back,\
        snils=args.snils,bank=args.bank,bik=args.bik,korespond_amount=str(message.text))



# ----Получить разчётный счёт нового курьера----
@bot.message_handler(func=lambda message: fsm.get_state(message.from_user.id).state == "currier_reg_get_raz_amount")
@log
def start_as_currier_get_raz_amount_update(message):
    language = language_check(message.from_user.id)
    args = fsm.get_state(message.from_user.id).args
    markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
    bot.send_message(message.chat.id,language["new_currier_menu"]["register_steps"]["get_inn"],reply_markup=markup)
    fsm.set_state(message.chat.id,"currier_reg_get_inn",move_type=args.move_type,name=args.name,birthday=args.birthday,email=args.email, \
        passport=args.passport,selfie=args.selfie,drive_front=args.drive_front,drive_back=args.drive_back,\
        snils=args.snils,bank=args.bank,bik=args.bik,korespond_amount=args.korespond_amount,raz_amount=str(message.text))



# ----Получить  ИНН нового курьера----
@bot.message_handler(func=lambda message: fsm.get_state(message.from_user.id).state == "currier_reg_get_inn")
@log
def start_as_currier_get_inn_update(message):
    language = language_check(message.from_user.id)
    args = fsm.get_state(message.from_user.id).args
    markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
    bot.send_message(message.chat.id,language["new_currier_menu"]["register_steps"]["get_phone"],reply_markup=markup)
    fsm.set_state(message.chat.id,"currier_reg_get_phone",move_type=args.move_type,name=args.name,birthday=args.birthday,email=args.email, \
        passport=args.passport,selfie=args.selfie,drive_front=args.drive_front,drive_back=args.drive_back,\
        snils=args.snils,bank=args.bank,bik=args.bik,korespond_amount=args.korespond_amount,raz_amount=args.raz_amount,inn=str(message.text))



# ----Получить  номер телефона  нового курьера----
@bot.message_handler(func=lambda message: fsm.get_state(message.from_user.id).state == "currier_reg_get_phone")
@log
def start_as_currier_get_phone_update(message):
    language = language_check(message.from_user.id)
    args = fsm.get_state(message.from_user.id).args
    try_code = send_confrim_code(str(message.text))
    print(try_code)
    markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
    if not try_code:
        bot.send_message(message.chat.id,language["new_currier_menu"]["register_steps"]["get_phone_error"],reply_markup=markup)
        return
    bot.send_message(message.chat.id,language["new_currier_menu"]["register_steps"]["get_code"],reply_markup=markup)
    fsm.set_state(message.chat.id,"currier_reg_get_code",move_type=args.move_type,name=args.name,birthday=args.birthday,email=args.email, \
        passport=args.passport,selfie=args.selfie,drive_front=args.drive_front,drive_back=args.drive_back,\
        snils=args.snils,bank=args.bank,bik=args.bik,korespond_amount=args.korespond_amount,raz_amount=args.raz_amount,inn=args.inn,phone=str(message.text),code=str(try_code))





# ----Получить код подтверждения нового курьера----
@bot.message_handler(func=lambda message: fsm.get_state(message.from_user.id).state == "currier_reg_get_code")
@log
def start_as_currier_get_phone_code_update(message):
    language = language_check(message.from_user.id)
    args = fsm.get_state(message.from_user.id).args
    markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
    if str(message.text) != str(args.code):
        bot.send_message(message.chat.id,language["new_currier_menu"]["register_steps"]["get_code_error"],reply_markup=markup)
        return
    fsm.remove_state(message.from_user.id)
    insert_map = {
        "user_id":int(message.chat.id),
        "accept_state":False,
        "name":args.name,
        "move_type":args.move_type,
        "birthday":args.birthday,
        "email":args.email,
        "passport":args.passport,
        "selfie":args.selfie,
        "drive_front":args.drive_front,
        "drive_back":args.drive_back,
        "snils":args.snils,
        "bank":args.bank,
        "bik":args.bik,
        "korespond_amount":args.korespond_amount,
        "raz_amount":args.raz_amount,
        "inn":args.inn,
        "phone":args.phone,
        "debt_balans":float(0),
        "income_balans":float(0)}
    base.insert("currier_base",insert_map)
    car_map_text = language["new_currier_menu"]["move_type_names"]
    move_type_mode = str(args.move_type).split("_")[0]
    move_type_ctype = str(args.move_type).split("_")[1]
    move_type_text = "{}-{}".format(car_map_text[move_type_mode],car_map_text[move_type_ctype])
    text_to_sent = language["new_currier_menu"]["request_format"].format(args.name,args.birthday,args.email,args.snils,args.bank,args.bik,args.korespond_amount,args.raz_amount,move_type_text,args.inn,args.phone)
    msg = bot.send_message(config.MODER_CURRIER_CHANNEL,text_to_sent)
    bot.send_photo(config.MODER_CURRIER_CHANNEL,args.passport)
    bot.send_photo(config.MODER_CURRIER_CHANNEL,args.selfie)
    if move_type_mode != "r":
        bot.send_photo(config.MODER_CURRIER_CHANNEL,args.drive_front)
        bot.send_photo(config.MODER_CURRIER_CHANNEL,args.drive_back)
    markup = tools.create_inlineKeyboard({language["new_currier_menu"]["request_to_but"][0]:"new_currier_accept {}".format(message.chat.id),language["new_currier_menu"]["request_to_but"][1]:"new_currier_decline {}".format(message.chat.id)})
    bot.reply_to(msg,language["new_currier_menu"]["request_to_text"],reply_markup=markup)
    bot.send_message(message.chat.id,language["new_currier_menu"]["sent_to_moder"])





# ----Одобрить заявку нового нового курьера----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split(" ")[0]) == "new_currier_accept")
@log
def admin_accept_new_currier_update(call):
    language = language_check(call.from_user.id)
    user_id = int(call.data.split(" ")[1])
    base.update("currier_base",{"accept_state":True},user_id=user_id)
    bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=language["new_currier_menu"]["request_accepted"])
    bot.send_message(user_id,language["new_currier_menu"]["currier_request_ok"])



# ----Отклонить заявку нового нового курьера----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split(" ")[0]) == "new_currier_decline")
@log
def admin_decline_new_currier_update(call):
    language = language_check(call.from_user.id)
    user_id = int(call.data.split(" ")[1])
    markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
    bot.send_message(call.message.chat.id,language["new_currier_menu"]["request_get_cancel_text"],reply_markup=markup)
    fsm.set_state(call.from_user.id,"admin_get_courrier_decline_text",to_user_id=user_id,msg_id=call.message.message_id)




# ----Получить текст отклонения заявки курьера----
@bot.message_handler(func=lambda message: fsm.get_state(message.from_user.id).state == "admin_get_courrier_decline_text")
@log
def admin_get_decline_new_currier_text_update(message):
    language = language_check(message.from_user.id)
    args = fsm.get_state(message.from_user.id).args
    fsm.remove_state(message.from_user.id)
    user_id = args.to_user_id
    base.delete("currier_base",user_id=user_id)
    bot.edit_message_text(chat_id=message.chat.id,message_id=args.msg_id,text=language["new_currier_menu"]["request_canceled"])
    bot.send_message(user_id,language["new_currier_menu"]["currier_request_cancel"].format(str(message.text)))
    bot.send_message(message.chat.id,language["new_currier_menu"]["request_canceled"])



# ----Предухранение доступа человека к курьерских фнукциям(сообщения)----
@bot.message_handler(func=lambda message: not base.test("currier_base",user_id=int(message.from_user.id)) )
@log
def not_currier_prestop_message(message):
    print("NOT CURRIER STOP")


# ----Предухранение доступа человека к курьерских фнукциям(кнопки)----
@bot.callback_query_handler(func=lambda call: str(call.data) != "cancel_hundler" and not base.test("currier_base",user_id=int(call.from_user.id)))
@log
def not_currier_prestop_call(call):
    print("NOT CURRIER STOP")




#####################--Главное меню--################################################




# ----Активные заказы----
@bot.message_handler(func=lambda message: True and message.text == language_check(message.from_user.id)["currier_menu"]["menu"][0])
@log
def main_menu_active_order_update(message):
    language = language_check(message.from_user.id)
    active_status = config.CURRIER_ACTIVE_STATUS
    select_list = {}
    for status in active_status:
        test_status = '{}%'.format(status)
        data = base.select_where("order_base",{"currier_id":int(message.chat.id),"state":test_status},like_prefix=["state"])
        if data:
            for one_data in data:
                select_list["#{}".format(one_data[0])] = "active_order_menu {}".format(one_data[0])
    
    if len(select_list) == 0:
        bot.send_message(message.chat.id,language["active_order_menu"]["now_is_null"])
    else:
        bot.send_message(message.chat.id,language["active_order_menu"]["select_order"],reply_markup=tools.create_inlineKeyboard(select_list))



# ----Завершенные заказы----
@bot.message_handler(func=lambda message: True and message.text == language_check(message.from_user.id)["currier_menu"]["menu"][1])
@log
def main_menu_finish_order_update(message):
    language = language_check(message.from_user.id)
    select_list = {}
    test_status = 'finish%'
    data = base.select_where("order_base",{"currier_id":int(message.chat.id),"state":test_status},like_prefix=["state"])
    if data:
        for one_data in data:
            select_list["#{}".format(one_data[0])] = "select_old_order {}".format(one_data[0])
    if len(select_list) != 0:
        bot.send_message(message.chat.id,language["currier_menu"]["old_order"]["select"],reply_markup=tools.create_inlineKeyboard(select_list))
    else:
        bot.send_message(message.chat.id,language["currier_menu"]["old_order"]["null"])





# ----Кабинет---
@bot.message_handler(func=lambda message: True and message.text == language_check(message.from_user.id)["currier_menu"]["menu"][2])
@log
def main_menu_cab_update(message):
    language = language_check(message.from_user.id)
    curreir_data = base.select_one("currier_base",user_id=int(message.chat.id))
    debt_balans = float(curreir_data[17])
    income_balans = float(curreir_data[18])
    format_text =   language["currier_menu"]["currier_cab"]["text_format"].format(debt_balans,income_balans)
    markup = {
        language["currier_menu"]["currier_cab"]["up_debt_but"] :"cab_debt_up"
    }
    bot.send_message(message.chat.id,format_text,reply_markup=tools.create_inlineKeyboard(markup))




# ----Пополнить задолженость----
@bot.callback_query_handler(func=lambda call: True and str(call.data).split(" ")[0] == "cab_debt_up")
@log
def up_debt_button_update(call):
    language = language_check(call.from_user.id)
    curreir_data = base.select_one("currier_base",user_id=int(call.message.chat.id))
    debt_balans = float(curreir_data[17])
    if debt_balans < 1:
        bot.answer_callback_query(callback_query_id=call.id,show_alert=True,text=language["currier_menu"]["currier_cab"]["debt_null"])
        return
    unic_id = generate_hash()
    new_invoice = qiwi_pay.create_invoice(unic_id,float(order_data.price))
    if not new_invoice:
        return
    pay_link = new_invoice["payUrl"]        
    keyboard = telebot.types.InlineKeyboardMarkup()
    keyboard.add(telebot.types.InlineKeyboardButton(text=language["new_order_menu"]["payment_menu"]["pay_link_but"], url=pay_link))
    keyboard.add(telebot.types.InlineKeyboardButton(text=language["new_order_menu"]["payment_menu"]["pay_link_but_ok"], callback_data="paid_check debt {}".format(unic_id)))
    bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=language["new_order_menu"]["payment_menu"]["pay_link_text"],reply_markup=keyboard)









# ----Справка---
@bot.message_handler(func=lambda message: True and message.text == language_check(message.from_user.id)["currier_menu"]["menu"][3])
@log
def main_menu_info_update(message):
    language = language_check(message.from_user.id)
    markup = {}
    skip = False
    for info_but in language["currier_menu"]["info_section"]:
        if skip:
            skip = False
            continue
        else:
            skip = True 
        markup[language["currier_menu"]["info_section"][info_but]] = "main_menu_info {}".format(info_but)
    markup = tools.create_inlineKeyboard(markup)
    bot.send_message(message.chat.id,language["currier_menu"]["info_section_select_question_text"],reply_markup=markup)





# ----Справка-Выбрать вопрос----
@bot.callback_query_handler(func=lambda call: True and str(call.data).split(" ")[0] == "main_menu_info")
@log
def main_menu_info_select_answer(call):
    language = language_check(call.from_user.id)
    q_name = str(call.data.split(" ")[1])
    answer_name = "{}_answer".format(q_name)
    markup = {}
    skip = False
    for info_but in language["currier_menu"]["info_section"]:
        if skip:
            skip = False
            continue
        else:
            skip = True 
        markup[language["currier_menu"]["info_section"][info_but]] = "main_menu_info {}".format(info_but)
    markup = tools.create_inlineKeyboard(markup)

    msg = bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=language["currier_menu"]["info_section"][answer_name])
    bot.reply_to(msg,language["currier_menu"]["info_section_select_question_text"],reply_markup=markup)



#####################--Работа с активными заказами--################################################


# ----Взять новый заказ----
@bot.callback_query_handler(func=lambda call: True and str(call.data).split(" ")[0] == "accept_order")
@log
def accept_new_order_update(call):
    language = language_check(call.from_user.id)
    order_id = int(call.data.split(" ")[1])
    order_data = base.select_one("order_base",id=order_id)
    if not order_data:
        return
    order_data = get_order_by_data(order_data)
    active_status = config.ORDER_WAIT_STATUS
    if order_data.state not in active_status:
        return
    if order_data.currier_id and int(order_data.currier_id) == 0:
        return
    status_data = str(order_data.state).split("_")
    new_status = "getedCurrier_{}".format(status_data[1])
    base.update("order_base",{"state":new_status,"currier_id":int(call.from_user.id)},id=order_id)
    bot.delete_message(chat_id=call.message.chat.id,message_id=call.message.message_id)
    bot.send_message(call.from_user.id,language["currier_menu"]["accepted_order"].format(order_data.id))
    cur_data = base.select_one("currier_base",user_id=int(call.from_user.id))
    name = ""
    if cur_data:
        name = str(cur_data[2])
    send_sms(order_data.owner_phone,language["sms_templates"]["currier_geted_order"].format(order_id,name))
    servis_bot.send_message(order_data.user_id,language["sms_templates"]["currier_geted_order"].format(order_id,name))



def form_order_msg(language,order_data):
    go_adress_data = ""
    upd_info = ""
    num = 1
    for iter_adress in order_data.go_data:
        add_iter = language["currier_menu"]["active_order_menu"]["adress_format"].format(num,iter_adress.location,iter_adress.time,iter_adress.name,iter_adress.phone)
        go_adress_data += add_iter
        num += 1
    temp_text = "-"
    if order_data.taiming_mode:
        temp_text = "+"
    if order_data.edit_text:
        upd_info = str(language["currier_menu"]["active_order_menu"]["format_upd_info"]) + str(order_data.edit_text)
    text = language["currier_menu"]["active_order_menu"]["format"].format(order_data.id,order_data.get_location,order_data.get_time,go_adress_data,temp_text,order_data.currier_display_price,order_data.comment,upd_info)
    return text



# ----Выбрать активный заказ----
@bot.callback_query_handler(func=lambda call: True and str(call.data).split(" ")[0] == "active_order_menu")
@log
def select_active_order_update(call):
    language = language_check(call.from_user.id)
    order_id = int(call.data.split(" ")[1])
    data = base.select_one("order_base",id=int(order_id))
    if not data:
        return
    data  = get_order_by_data(data)
    msg = form_order_msg(language,data)
    status_data = str(data.state).split("_")

    if status_data[0] == "getedCurrier":
        markup = {language["currier_menu"]["active_order_menu"]["buts"]["get_order_in_point"]:"order_state_getted_order {}".format(data.id)}
    elif status_data[0] == "waitCurrierDelivery":
        adress_id = str(status_data[2])
        markup = {language["currier_menu"]["active_order_menu"]["buts"]["go_order"].format(int(adress_id) + 1):"order_state_take_order {} {}".format(data.id,adress_id)}
    markup = tools.create_inlineKeyboard(markup)
    bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=msg,reply_markup=markup)


# ----Выбрать старый заказ----
@bot.callback_query_handler(func=lambda call: True and str(call.data).split(" ")[0] == "select_old_order")
@log
def select_old_order_update(call):
    language = language_check(call.from_user.id)
    order_id = int(call.data.split(" ")[1])
    data = base.select_one("order_base",id=int(order_id))
    if not data:
        return
    data  = get_order_by_data(data)
    msg = form_order_msg(language,data)
    msg = bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=msg)
    bot.reply_to(msg,language["currier_menu"]["old_order"]["rating"].format(language["currier_menu"]["old_order"]["not_rate"]))





# ----Забрал товар из точки----
@bot.callback_query_handler(func=lambda call: True and str(call.data).split(" ")[0] == "order_state_getted_order")
@log
def active_geted_order_update(call):
    language = language_check(call.from_user.id)
    order_id = int(call.data.split(" ")[1])
    data = base.select_one("order_base",id=int(order_id))
    if not data:
        return
    data  = get_order_by_data(data)
    status_data = str(data.state).split("_")
    new_status = "waitCurrierDelivery_{}_0".format(status_data[1])
    base.update("order_base",{"state":new_status},id=order_id)
    markup = {language["currier_menu"]["active_order_menu"]["buts"]["go_order"].format(1):"order_state_take_order {} 0".format(data.id)}
    markup = tools.create_inlineKeyboard(markup)
    bot.edit_message_reply_markup(chat_id=call.message.chat.id,message_id=call.message.message_id,reply_markup=markup)




# ----Доставил по адрессу----
@bot.callback_query_handler(func=lambda call: True and str(call.data).split(" ")[0] == "order_state_take_order")
@log
def active_take_order_update(call):
    language = language_check(call.from_user.id)
    order_id = int(call.data.split(" ")[1])
    adress_id = int(call.data.split(" ")[2])
    data = base.select_one("order_base",id=int(order_id))
    if not data:
        return
    data  = get_order_by_data(data)
    status_data = str(data.state).split("_")
    current_adress_phone = data.go_data[adress_id].phone
    send_sms(current_adress_phone,language["sms_templates"]["currier_geted_flower"].format(order_id))
    if (len(data.go_data) - 1) != adress_id:
        new_status = "waitCurrierDelivery_{}_{}".format(status_data[1],adress_id+1)
        base.update("order_base",{"state":new_status},id=order_id)
        markup = {language["currier_menu"]["active_order_menu"]["buts"]["go_order"].format(adress_id+1):"order_state_take_order {} {}".format(data.id,adress_id+1)}
        markup = tools.create_inlineKeyboard(markup)
        bot.edit_message_reply_markup(chat_id=call.message.chat.id,message_id=call.message.message_id,reply_markup=markup) 
        return
    new_status = "finish_{}".format(status_data[1])
    base.update("order_base",{"state":new_status},id=order_id)
    curreir_data = base.select_one("currier_base",user_id=int(data.currier_id))
    debt_balans = float(curreir_data[17])
    income_balans = float(curreir_data[18])

    if str(status_data[1]) == "nal":
        to_pricing =  debt_balans + (float(data.price) / 100 * 15)
        base.update("currier_base",{"debt_balans":to_pricing},user_id=int(data.currier_id))
    else:
        to_pricing = income_balans + (float(data.price) - (float(data.price) / 100 * 15))
        base.update("currier_base",{"income_balans":to_pricing},user_id=int(data.currier_id))
    bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=language["currier_menu"]["active_order_menu"]["finish"])





#####################--Платежи--################################################


# ----Проверка оплаты----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split(" ")[0]) == "paid_check")
@log
def qiwi_paid_check_update(call):
    language = language_check(call.from_user.id)
    do_type = str(call.data.split(" ")[1])
    unic_id = str(call.data.split(" ")[2])
    pay_data = qiwi_pay.check_invoice(unic_id)
    if pay_data["status"]["value"] != "PAID":
        bot.answer_callback_query(callback_query_id=call.id,show_alert=False,text="NOT PAID ERROR...")
        return
    if do_type == "debt":
        price = float(pay_data["amount"]["value"])
        curreir_data = base.select_one("currier_base",user_id=int(call.message.chat.id))
        debt_balans = float(curreir_data[17])
        new_nebt = debt_balans - price
        base.update("currier_base",{"debt_balans":new_nebt},user_id=int(call.message.chat.id))
        bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=language["currier_menu"]["currier_cab"]["payments_ok"])





#####################--Общие функции--################################################


# ----Отменить хендлер----
@bot.callback_query_handler(func=lambda call: True and str(call.data) == "cancel_hundler")
@log
def two_cancel_hundler(call):
    language = language_check(call.from_user.id)
    fsm.remove_state(call.from_user.id)
    markup = False
    bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=language["cancel_hundler_ok"],reply_markup=markup)




# ----Незарегистрированые сообщения----
@bot.message_handler(func=lambda message: True)
@log
def all_msg(message):
    print(" -> NOT REGISTER")

# ----Незарегистрированые кнопки----
@bot.callback_query_handler(func=lambda call: True)
@log
def all_callback(call):
    print(" -> NOT REGISTER")