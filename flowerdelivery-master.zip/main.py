from app import base,fsm,bot,cur_bot,qiwi_pay
from datetime import datetime
from bot_utils import log
from bot_middleware import language_check,send_confrim_code,to_base_binary_data,get_order_by_data,get_percent_data,is_admin,generate_hash
from tools import validate_email
from payment import PayController
from bot_utils import send_new_order_to_channel
import bot_utils as tools
import keyboards as menu
import telebot
import config
import bot_models
import traceback


@bot.message_handler(func=lambda message: True and base.test("block_user",user_id=int(message.from_user.id)))
def block_skip(message):
	pass


#####################--Регистрация--################################################


# ----Обработка команды /start (первое сообщения юзера)----
@bot.message_handler(commands=['start'])
@log
def start_update(message):
	if not base.test("bot_user",user_id=int(message.from_user.id)):
		base.insert("bot_user",{"user_id":int(message.from_user.id),"language":"ru","username":str(message.from_user.username),"balans":0})
	language = language_check(message.from_user.id)
	bot.send_message(message.chat.id,language["welcome_text"],reply_markup=menu.get_main_menu(language))



# ----Обработка команды /get_chat_id----
@bot.message_handler(commands=['get_chat_id'])
def get_chat_id_update(message):
	bot.send_message(message.chat.id,str(message.chat.id))


@bot.channel_post_handler(commands=['get_chat_id'])
def get_chat_id_channel_update(message):
	get_chat_id_update(message)




#####################--Главное меню--################################################



# ----Меню заказов из главного меню----
@bot.message_handler(func=lambda message: True and message.text == language_check(message.from_user.id)["main_menu"][0])
def main_menu_orders_update(message):
	language = language_check(message.from_user.id)
	bot.send_message(message.chat.id,language["reply_markups"]["main_menu_order_section_text"],reply_markup=menu.get_main_order_menu(language))


# ----Активные заказы из главного меню----
@bot.message_handler(func=lambda message: True and message.text == language_check(message.from_user.id)["main_menu"][1])
def main_menu_active_orders_update(message):
	language = language_check(message.from_user.id)
	active_status = config.CUSTOMER_ACTIVE_STATUS
	select_list = {}
	for status in active_status:
		test_status = '{}%'.format(status)
		data = base.select_where("order_base",{"user_id":int(message.chat.id),"state":test_status},like_prefix=["state"])
		if data:
			for one_data in data:
				select_list["#{}".format(one_data[0])] = "user_select_order {}".format(one_data[0])
	
	if len(select_list) == 0:
		bot.send_message(message.chat.id,language["currier_menu"]["active_order_menu"]["now_is_null"])
	else:
		bot.send_message(message.chat.id,language["currier_menu"]["active_order_menu"]["select_order"],reply_markup=tools.create_inlineKeyboard(select_list))





# ----Мой кабинет----
@bot.message_handler(func=lambda message: True and message.text == language_check(message.from_user.id)["main_menu"][2])
def main_menu_mycab_update(message):
	language = language_check(message.from_user.id)
	data = base.select_one("bot_user",user_id=int(message.from_user.id))
	balans = float(data[3])
	text = language["mycab_menu"]["text"].format(balans)
	markup = tools.create_inlineKeyboard({language["mycab_menu"]["balans_up_but"]:"mycab_balans_up"})
	bot.send_message(message.chat.id,text,reply_markup=markup)

'''
# ----Стать курьеом----
@bot.message_handler(func=lambda message: True and message.text == language_check(message.from_user.id)["main_menu"][3])
def main_menu_start_as_currier_update(message):
	language = language_check(message.from_user.id)
	bot.send_message(message.chat.id,language["reply_markups"]["main_menu_start_as_currier_text"],reply_markup=menu.get_main_menu_currier_menu(language))
'''


# ----О нас----
@bot.message_handler(func=lambda message: True and message.text == language_check(message.from_user.id)["main_menu"][3])
def main_menu_about_us_update(message):
	language = language_check(message.from_user.id)
	bot.send_message(message.chat.id,language["about_us"])


# ----Назад в главное меню----
@bot.message_handler(func=lambda message: True and message.text == language_check(message.from_user.id)["back_to_main_menu"])
def back_to_main_menu_update(message):
	language = language_check(message.from_user.id)
	bot.send_message(message.chat.id,language["back_to_main_menu_text"],reply_markup=menu.get_main_menu(language))




#####################--Меню заказов--################################################


def form_order_msg(language,order_data):
	"""Формировать текст заказа"""
	status_data = str(order_data.state).split("_")
	status = language["order_data"]["state_maping"][status_data[0]]
	payment = language["order_data"]["pay_maping"][status_data[1]]
	upd_info = ""
	go_adress_data = ""
	num = 1
	for iter_adress in order_data.go_data:
		add_iter = "\n{}) {} - {}".format(num,iter_adress.location,iter_adress.time)
		go_adress_data += add_iter
		num += 1

	if order_data.edit_text:
		upd_info = str(language["order_data"]["format_upd_info"]) + str(order_data.edit_text)
	text = language["order_data"]["format"].format(order_data.id,status,order_data.get_location,order_data.get_time,go_adress_data,order_data.price,payment,upd_info)
	return text





# ACTIVE ORDER



# ----Подверждение отмены выбраного заказа----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split(" ")[0]) == "cancel_order_sure")
@log
def active_order_cancel_sure_update(call):
	language = language_check(call.from_user.id)
	order_id = str(call.data.split(" ")[1])
	do = str(call.data.split(" ")[2])
	if do == "no":
		bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=language["active_order_menu"]["cancel_order_attention"]["not"])
		return
	data = base.select_one("order_base",id=int(order_id))
	if not data:
		return
	data = get_order_by_data(data)
	state_data = str(data.state).split("_")
	new_state = "{}_{}".format("cancel",state_data[1])
	if str(state_data[1]) == "online" or str(state_data[1]) == "balans":
		price = float(data.price)
		current_balans = float(base.select_one("bot_user",user_id=int(call.from_user.id))[3])
		base.update("bot_user",{"balans":current_balans+price},user_id=int(call.from_user.id))
	base.update("order_base",{"state":new_state},id=int(order_id))
	bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=language["active_order_menu"]["cancel_order_attention"]["ok"])



# ----Отменить выбраный заказ----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split(" ")[0]) == "active_order_cancel")
@log
def active_order_cancel_update(call):
	language = language_check(call.from_user.id)
	order_id = str(call.data.split(" ")[1])
	language["active_order_menu"]["cancel_order_attention"]["menu"]
	markup = {
		language["active_order_menu"]["cancel_order_attention"]["menu"][0]:"cancel_order_sure {} yes".format(order_id),
		language["active_order_menu"]["cancel_order_attention"]["menu"][1]:"cancel_order_sure {} no".format(order_id)
	}
	bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=language["active_order_menu"]["cancel_order_attention"]["your_sure"],reply_markup=tools.create_inlineKeyboard(markup))



# ---Получить текст для измнения заказа----
@bot.message_handler(content_types="text",func=lambda message: fsm.get_state(message.from_user.id).state == "edit_order_get_text")
@log
def active_order_edit_get_text_update(message):
	language = language_check(message.from_user.id)
	args = fsm.get_state(message.from_user.id).args
	fsm.remove_state(message.from_user.id)
	order_id = int(args.order_id)
	base.update("order_base",{"edit_text":str(message.text)},id=order_id)
	bot.send_message(message.chat.id,language["active_order_menu"]["edit_order"]["write_new_text_ok"])



# ----Изменить выбраный заказ----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split(" ")[0]) == "active_order_edit")
@log
def active_order_edit_update(call):
	language = language_check(call.from_user.id)
	order_id = str(call.data.split(" ")[1])
	markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
	fsm.set_state(call.from_user.id,"edit_order_get_text",order_id=order_id)
	bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=language["active_order_menu"]["edit_order"]["write_new_text"],reply_markup=markup)



# ----Написать курьеру из  выбраного заказа----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split(" ")[0]) == "active_order_msg_to_currier")
@log
def active_order_msg_to_currier_update(call):
	language = language_check(call.from_user.id)
	order_id = str(call.data.split(" ")[1])
	bot.answer_callback_query(callback_query_id=call.id,show_alert=True,text=language["active_order_menu"]["msg_to_currier"]["not_currier"])


# ----Выбрать заказ----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split(" ")[0]) == "user_select_order")
@log
def active_order_select_update(call):
	language = language_check(call.from_user.id)
	order_id = str(call.data.split(" ")[1])
	data = base.select_one("order_base",id=int(order_id))
	data  = get_order_by_data(data)
	text = form_order_msg(language,data)
	bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=text,parse_mode="Markdown")
	markup = {
		language["active_order_menu"]["selected_order_menu"][0]:"active_order_edit {}".format(order_id),
		language["active_order_menu"]["selected_order_menu"][1]:"active_order_cancel {}".format(order_id),
		language["active_order_menu"]["selected_order_menu"][2]:"active_order_msg_to_currier {}".format(order_id)}
	bot.reply_to(call.message,language["active_order_menu"]["select_action"],reply_markup=tools.create_inlineKeyboard(markup))



# OLD ORDER


# ----Завершенные заказы----
@bot.message_handler(func=lambda message: True and message.text == language_check(message.from_user.id)["reply_markups"]["main_menu_order_section"][1])
def order_menu_old_order_update(message):
	language = language_check(message.from_user.id)
	select_list = {}
	test_status = 'finish%'
	data = base.select_where("order_base",{"user_id":int(message.chat.id),"state":test_status},like_prefix=["state"])
	if data:
		for one_data in data:
			select_list["#{}".format(one_data[0])] = "user_select_old_order {}".format(one_data[0])
	if len(select_list) != 0:
		bot.send_message(message.chat.id,language["old_order_menu"]["select_order"],reply_markup=tools.create_inlineKeyboard(select_list))
	else:
		bot.send_message(message.chat.id,language["old_order_menu"]["now_is_null"])



# ----Выбрать старый заказ----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split(" ")[0]) == "user_select_old_order")
@log
def old_order_select_update(call):
	language = language_check(call.from_user.id)
	order_id = str(call.data.split(" ")[1])
	data = base.select_one("order_base",id=int(order_id))
	data  = get_order_by_data(data)
	text = form_order_msg(language,data)
	bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=text,parse_mode="Markdown")
	markup = {
		language["old_order_menu"]["selected_order_menu"][0]:"old_order_rate {}".format(order_id),
		language["old_order_menu"]["selected_order_menu"][1]:"old_order_report {}".format(order_id)}
	bot.reply_to(call.message,language["old_order_menu"]["select_do"],reply_markup=tools.create_inlineKeyboard(markup))




# NEW ORDER


# ----Новый заказ----
@bot.message_handler(func=lambda message: True and message.text == language_check(message.from_user.id)["reply_markups"]["main_menu_order_section"][0])
def order_menu_new_order_update(message):
	language = language_check(message.from_user.id)
	all_list = base.select_where("save_adress_base",{"user_id":int(message.chat.id)})
	markup = {language["new_order_menu"]["new_button"]:"cab_new_adress nxt_ord"}
	for i in all_list:
		markup[i[2]] = "order_by_adress {}".format(i[0])
	bot.send_message(message.chat.id,language["new_order_menu"]["select_get_adress"],reply_markup=tools.create_inlineKeyboard(markup))



# ----Выбор адреса забора для заказа----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split(" ")[0]) == "order_by_adress")
@log
def new_order_select_get_location_saved_update(call):
	language = language_check(call.from_user.id)
	adress_id = str(call.data.split(" ")[1])
	markup = tools.create_inlineKeyboard({language["new_order_menu"]["need_timing_menu"][0]:"new_order_timing {} 1".format(adress_id),language["new_order_menu"]["need_timing_menu"][1]:"new_order_timing {} 0".format(adress_id),language["cancel_hundler_but"]:"cancel_hundler"})
	bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=language["new_order_menu"]["need_timing"],reply_markup=markup)




# ----Выбор срочности нового заказа----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split(" ")[0]) == "new_order_timing")
@log
def new_order_get_timing_update(call):
	language = language_check(call.from_user.id)
	adress_id = str(call.data.split(" ")[1])
	timing_need = str(call.data.split(" ")[2])
	markup = tools.create_inlineKeyboard({language["new_order_menu"]["need_garant_menu"][0]:"new_order_garant {} {} 1".format(adress_id,timing_need),language["new_order_menu"]["need_garant_menu"][1]:"new_order_garant {} {} 0".format(adress_id,timing_need),language["cancel_hundler_but"]:"cancel_hundler"})
	bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=language["new_order_menu"]["need_garant"],reply_markup=markup)


		

# ----Выбор гарантии нового заказа----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split(" ")[0]) == "new_order_garant")
@log
def new_order_get_garanted_update(call):
	try:
		language = language_check(call.from_user.id)
		adress_id = str(call.data.split(" ")[1])
		timing_need = bool(int(call.data.split(" ")[2]))
		need_garant = bool(int(call.data.split(" ")[3]))
		markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
		if need_garant:
			fsm.set_state(call.message.chat.id,"new_order_get_garanted_price",adress_id=adress_id,need_garant=need_garant,timing_need=timing_need)
			bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=language["new_order_menu"]["need_garant_get_price"],reply_markup=markup)
			return
		fsm.set_state(call.message.chat.id,"new_order_get_gptime",adress_id=adress_id,need_garant=need_garant,need_garant_price=0,timing_need=timing_need)
		bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=language["new_order_menu"]["get_gtime"],reply_markup=markup)
	except:
		error_info = str(traceback.format_exc())
		print(error_info)







# ----Цена товаров для гарантии нового заказа----
@bot.message_handler(func=lambda message: fsm.get_state(message.from_user.id).state == "new_order_get_garanted_price")
@log
def new_order_get_garanted_price_update(message):
	language = language_check(message.from_user.id)
	args = fsm.get_state(message.from_user.id).args
	markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
	try:
		price = float(message.text)
	except:
		bot.send_message(message.chat.id,language["new_order_menu"]["price_error"],reply_markup=markup)
		return
	fsm.set_state(message.chat.id,"new_order_get_gptime",adress_id=args.adress_id,need_garant=args.need_garant,timing_need=args.timing_need,need_garant_price=price)
	bot.send_message(message.chat.id,language["new_order_menu"]["get_gtime"],reply_markup=markup)


# ----Время забора нового заказа----
@bot.message_handler(func=lambda message: fsm.get_state(message.from_user.id).state == "new_order_get_gptime")
@log
def new_order_get_gp_time_update(message):
	language = language_check(message.from_user.id)
	args = fsm.get_state(message.from_user.id).args
	markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
	fsm.set_state(message.chat.id,"new_order_get_phone",adress_list=[],adress_id=args.adress_id,need_garant=args.need_garant,timing_need=args.timing_need,need_garant_price=args.need_garant_price,gp_time=str(message.text))
	bot.send_message(message.chat.id,language["new_order_menu"]["get_phone_g"],reply_markup=markup)



# ----Телефон получателя нового заказа----
@bot.message_handler(func=lambda message: fsm.get_state(message.from_user.id).state == "new_order_get_phone")
@log
def new_order_get_geter_phone_update(message):
	language = language_check(message.from_user.id)
	args = fsm.get_state(message.from_user.id).args
	markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
	price = None
	if len(args.adress_list) != 0:
		price = args.price
	fsm.set_state(message.chat.id,"new_order_get_name",price=price,adress_list=args.adress_list,adress_id=args.adress_id,need_garant=args.need_garant,timing_need=args.timing_need,need_garant_price=args.need_garant_price,gp_time=args.gp_time,phone=str(message.text))
	bot.send_message(message.chat.id,language["new_order_menu"]["get_name_g"],reply_markup=markup)


# ----Имя получателя нового заказа----
@bot.message_handler(func=lambda message: fsm.get_state(message.from_user.id).state == "new_order_get_name")
@log
def new_order_get_geter_name_update(message):
	language = language_check(message.from_user.id)
	args = fsm.get_state(message.from_user.id).args
	markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
	fsm.set_state(message.chat.id,"new_order_get_tolocation",price=args.price,adress_list=args.adress_list,adress_id=args.adress_id,need_garant=args.need_garant,timing_need=args.timing_need,need_garant_price=args.need_garant_price,gp_time=args.gp_time,phone=args.phone,name=str(message.text))
	bot.send_message(message.chat.id,language["new_order_menu"]["get_tolocation"],reply_markup=markup)


# ----Локация отправки нового заказа----
@bot.message_handler(content_types=['location', 'text'],func=lambda message: fsm.get_state(message.from_user.id).state == "new_order_get_tolocation")
@log
def new_order_get_to_location_update(message):
	language = language_check(message.from_user.id)
	args = fsm.get_state(message.from_user.id).args
	markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
	if message.location:
		location = "cords_location {}:{}".format(message.location.latitude, message.location.longitude)
	else:
		location = str(message.text)
	fsm.set_state(message.chat.id,"new_order_get_time",price=args.price,adress_list=args.adress_list,adress_id=args.adress_id,need_garant=args.need_garant,timing_need=args.timing_need,need_garant_price=args.need_garant_price,gp_time=args.gp_time,phone=args.phone,name=args.name,location=location)
	bot.send_message(message.chat.id,language["new_order_menu"]["get_time_g"],reply_markup=markup)



# ----Время получения нового заказа----
@bot.message_handler(func=lambda message: fsm.get_state(message.from_user.id).state == "new_order_get_time")
@log
def new_order_get_geter_time_update(message):
	language = language_check(message.from_user.id)
	args = fsm.get_state(message.from_user.id).args
	if len(args.adress_list) == 0:
		markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
		fsm.set_state(message.chat.id,"new_order_get_price",adress_list=args.adress_list,adress_id=args.adress_id,need_garant=args.need_garant,timing_need=args.timing_need,need_garant_price=args.need_garant_price,gp_time=args.gp_time,phone=args.phone,name=args.name,location=args.location,time=str(message.text))
		bot.send_message(message.chat.id,language["new_order_menu"]["get_price"],reply_markup=markup)
	else:
		markup = tools.create_inlineKeyboard({language["new_order_menu"]["skip_comment_but"]:"new_order_skip_comment",language["new_order_menu"]["more_adress_but"]:"new_order_more_adress",language["cancel_hundler_but"]:"cancel_hundler"})
		fsm.set_state(message.chat.id,"new_order_get_comment",adress_list=args.adress_list,adress_id=args.adress_id,need_garant=args.need_garant,timing_need=args.timing_need,need_garant_price=args.need_garant_price,gp_time=args.gp_time,phone=args.phone,name=args.name,time=str(message.text),location=args.location,price=args.price)
		bot.send_message(message.chat.id,language["new_order_menu"]["get_comment"],reply_markup=markup)



# ----Цена доставки нового заказа----
@bot.message_handler(func=lambda message: fsm.get_state(message.from_user.id).state == "new_order_get_price")
@log
def new_order_get_delivery_price_update(message):
	language = language_check(message.from_user.id)
	args = fsm.get_state(message.from_user.id).args
	markup = tools.create_inlineKeyboard({language["new_order_menu"]["skip_comment_but"]:"new_order_skip_comment",language["new_order_menu"]["more_adress_but"]:"new_order_more_adress",language["cancel_hundler_but"]:"cancel_hundler"})
	try:
		price = float(message.text)
	except:
		markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
		bot.send_message(message.chat.id,language["new_order_menu"]["price_error"],reply_markup=markup)
		return
	fsm.set_state(message.chat.id,"new_order_get_comment",adress_list=args.adress_list,adress_id=args.adress_id,need_garant=args.need_garant,timing_need=args.timing_need,need_garant_price=args.need_garant_price,gp_time=args.gp_time,phone=args.phone,name=args.name,time=args.time,location=args.location,price=price)
	bot.send_message(message.chat.id,language["new_order_menu"]["get_comment"],reply_markup=markup)




# ----Комментарий для нового заказа----
@bot.message_handler(func=lambda message: fsm.get_state(message.from_user.id).state == "new_order_get_comment")
@log
def new_order_get_comment_update(message,no_comment=False):
	language = language_check(message.chat.id)
	args = fsm.get_state(message.chat.id).args
	fsm.remove_state(message.chat.id)
	if not no_comment:
		comment = str(message.text)
	else:
		comment = ""
	get_data = base.select_one("save_adress_base",id=int(args.adress_id))
	price = float(args.price)
	plus = 0
	percent_data = get_percent_data()
	plus +=  (float(price) / 100 * int(percent_data["upperPrice"]))

	if args.need_garant:
		plus +=  (float(args.need_garant_price) / 100 * int(percent_data["needGarant"]))
	
	if args.timing_need:
		plus +=  (float(price) / 100 * int(percent_data["needTiming"]))
	
	price += plus
	currier_display_price = float(price) -  (float(price) / 100 * 15)
	adress_list = []
	for iter_adress in args.adress_list:
		add_adress = bot_models.OrderGoAdress(iter_adress["go_location"],iter_adress["go_phone"],iter_adress["go_name"],iter_adress["go_time"])
		adress_list.append(add_adress)
	add_adress = bot_models.OrderGoAdress(args.location,args.phone,args.name,args.time)
	adress_list.append(add_adress)	
	insert_map = { 
		"user_id":int(message.chat.id),
		"state":"wait_pay",
		"get_location":str(get_data[3]),
		"owner_phone":str(get_data[4]),
		"owner_name":str(get_data[5]),
		"get_time":args.gp_time,
		"go_data":to_base_binary_data(adress_list),
		"price":price,
		"garant":args.need_garant,
		"packed_price":args.need_garant_price,
		"taiming_mode":args.timing_need,
		"comment":comment,
		"currier_display_price":currier_display_price}
	new_id = base.insert("order_base",insert_map,return_id=True)
	markup = {
		language["new_order_menu"]["payment_menu"]["methods"][0]:"pay_order_method {} 0".format(new_id),
		language["new_order_menu"]["payment_menu"]["methods"][1]:"pay_order_method {} 1".format(new_id),
		language["new_order_menu"]["payment_menu"]["methods"][2]:"pay_order_method {} 2".format(new_id)}
	bot.send_message(message.chat.id,language["new_order_menu"]["payment_menu"]["select_payments_method"].format(price),reply_markup=tools.create_inlineKeyboard(markup))




# ----Пропустить комментарий для нового заказа----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split(" ")[0]) == "new_order_skip_comment")
@log
def new_order_skip_comment_update(call):
	new_order_get_comment_update(call.message,no_comment=True)



# ----Добавить ещё один адресс для заказа----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split(" ")[0]) == "new_order_more_adress")
@log
def new_order_more_adress_update(call):
	language = language_check(call.from_user.id)
	args = fsm.get_state(call.message.chat.id).args
	markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
	adress_list = list(args.adress_list)
	new_adr = {
		"go_location":args.location,
		"go_phone":args.phone,
		"go_name":args.name,
		"go_time":args.time
	}
	adress_list.append(new_adr)
	fsm.set_state(call.message.chat.id,"new_order_get_phone",adress_list=adress_list,adress_id=args.adress_id,need_garant=args.need_garant,timing_need=args.timing_need,need_garant_price=args.need_garant_price,gp_time=args.gp_time,price=args.price)
	bot.delete_message(chat_id=call.message.chat.id,message_id=call.message.message_id)
	bot.send_message(call.message.chat.id,language["new_order_menu"]["get_phone_g"],reply_markup=markup)




	


# ----Выбрать метод оплаты для нового заказа----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split(" ")[0]) == "pay_order_method")
@log
def new_order_select_method_update(call):
	language = language_check(call.from_user.id)
	order_id = int(call.data.split(" ")[1])
	method_id = int(call.data.split(" ")[2])
	order_data = base.select_one("order_base",id=order_id)
	if not order_data:
		return
	order_data = get_order_by_data(order_data)
	if method_id == 2: # balans
		data = base.select_one("bot_user",user_id=int(call.from_user.id))
		balans = float(data[3])
		if float(order_data.price) > balans:
			bot.send_message(call.message.chat.id,language["new_order_menu"]["payment_menu"]["balans_not"])
			return
		base.update("bot_user",{"balans":balans-float(order_data.price)},user_id=int(call.message.chat.id))
		base.update("order_base",{"state":"searthCurrier_balans"},id=order_id)
	elif method_id == 1: # online
		unic_id = generate_hash()
		new_invoice = qiwi_pay.create_invoice(unic_id,float(order_data.price))
		if not new_invoice:
			return
		pay_link = new_invoice["payUrl"]		
		keyboard = telebot.types.InlineKeyboardMarkup()
		keyboard.add(telebot.types.InlineKeyboardButton(text=language["new_order_menu"]["payment_menu"]["pay_link_but"], url=pay_link), telebot.types.InlineKeyboardButton(text=language["new_order_menu"]["payment_menu"]["ykassa"], callback_data=f'ykassa_{order_data.price}_{order_id}'))
		keyboard.add(telebot.types.InlineKeyboardButton(text=language["new_order_menu"]["payment_menu"]["pay_link_but_ok"], callback_data="paid_check order {} {}".format(unic_id,order_id)))
		bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=language["new_order_menu"]["payment_menu"]["pay_link_text"],reply_markup=keyboard)
		return
	elif method_id == 0: # nalik
		base.update("order_base",{"state":"searthCurrier_nal","currier_display_price":float(order_data.price)},id=order_id)
	send_new_order_to_channel(cur_bot,language,order_data,config.ORDER_CURRIER_CHANNEL)
	bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=language["new_order_menu"]["payment_menu"]["ok"])

# ----Отправить счет ЮКасса----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split("_")[0]) == "ykassa")
@log
def pay_ykassa(call):
	language = language_check(call.from_user.id)
	price = float(call.data.split("_")[1])
	order_id = int(call.data.split("_")[2])
	price = telebot.types.LabeledPrice(label='Оплата заказа', amount=price)
	bot.send_invoice(call.message.chat.id, title='Оплатить', provider_token=config.PAYMENTS_PROVIDER_TOKEN, prices=[price],start_parameter='payment_ykass', payload = f'{order_id}')

# ----Хендлер на оплату----
@bot.message_handler(content_types=['successful_payment'])
@log
def process_successful_payment(message: telebot.types.Message):
	payload = message.successful_payment.to_python().items['invoice_payload']
	if payload == 'upbalanceykassa':
		price = float(message.successful_payment.total_amount // 100)
		current_balans = float(base.select_one("bot_user",user_id=int(message.chat.id))[3])
		base.update("bot_user",{"balans":current_balans+price},user_id=int(message.chat.id))
		base.insert("payments_history",{"user_id":int(message.chat.id),"amount":price,"do_name":"balans_up"})
		bot.edit_message_text(chat_id=message.chat.id,message_id=message.message_id,text=language["mycab_menu"]["balans_up_ok"])
	else:
		order_id = int(message.successful_payment.to_python().items['invoice_payload'])
		order_data = base.select_one("order_base",id=order_id)
		if not order_data:
			return
		order_data = get_order_by_data(order_data)
		base.update("order_base",{"state":"searthCurrier_online"},id=order_id)
		send_new_order_to_channel(cur_bot,language,order_data,config.ORDER_CURRIER_CHANNEL)
		bot.send_message(message.chat.id, text=language["new_order_menu"]["payment_menu"]["ok"])

#####################--Личный кабинет--################################################



# ----Пополнить баланс---
@bot.callback_query_handler(func=lambda call: True and str(call.data.split(" ")[0]) == "mycab_balans_up")
@log
def cab_up_balans_update(call):
	language = language_check(call.from_user.id)
	markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
	fsm.set_state(call.from_user.id,"cab_up_balans_get_price")
	bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=language["mycab_menu"]["balans_up_get_price"],reply_markup=markup)

# ----Сумма пополнения баланса---
@bot.message_handler(func=lambda message: fsm.get_state(message.from_user.id).state == "cab_up_balans_get_price")
@log
def cab_up_balans_get_price_update(message):
	language = language_check(message.from_user.id)
	fsm.remove_state(message.chat.id)
	try:
		price = int(message.text)
	except Exception as e:
		bot.send_message(message.chat.id,language["mycab_menu"]["balans_up_get_price_error"])
		return
	#payment = PayController(bot,config.PAY_TOKEN)
	#payment.add_price("Пополнение баланса",price*100)
	#payment.create_invoice(message.chat.id,"Пополнение баланса","Пополнение личного баланса","balans_up",need_name=False,need_phone_number=False)
	unic_id = generate_hash()
	new_invoice = qiwi_pay.create_invoice(unic_id,float(message.text))
	if not new_invoice:
		return
	pay_link = new_invoice["payUrl"]		
	keyboard = telebot.types.InlineKeyboardMarkup()
	keyboard.add(telebot.types.InlineKeyboardButton(text=language["new_order_menu"]["payment_menu"]["pay_link_but"], url=pay_link), telebot.types.InlineKeyboardButton(text=language["new_order_menu"]["payment_menu"]["ykassa"], callback_data=f'upbalanceykassa_{price}'))
	keyboard.add(telebot.types.InlineKeyboardButton(text=language["new_order_menu"]["payment_menu"]["pay_link_but_ok"], callback_data="paid_check balans_up {}".format(unic_id)))	
	bot.send_message(message.chat.id,language["new_order_menu"]["payment_menu"]["pay_link_text"],reply_markup=keyboard)

#----Отправить счет на пополнение баланса ЮКасса----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split("_")[0]) == "upbalanceykassa")
@log
def pay_ykassa(call):
	language = language_check(call.from_user.id)
	price = float(call.data.split("_")[1])
	price = telebot.types.LabeledPrice(label='Пополнение баланс', amount=price)
	bot.send_invoice(call.message.chat.id, title='Пополнить личный баланс', provider_token=config.PAYMENTS_PROVIDER_TOKEN, prices=[price],start_parameter='upbalanceykassa', payload='upbalanceykassa')

# ----Добавить новый адресс забора----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split(" ")[0]) == "cab_new_adress")
@log
def cab_new_adress_update(call):
	language = language_check(call.from_user.id)
	next_order = False
	markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
	if len(call.data.split(" ")) >= 2 and str(call.data.split(" ")[1]) == "nxt_ord":
		markup = tools.create_inlineKeyboard({language["mycab_menu"]["new_adress"]["save_menu"][0]:"cab_new_adress nxt_ord_save",language["mycab_menu"]["new_adress"]["save_menu"][1]:"cab_new_adress nxt_ord_notsave",language["cancel_hundler_but"]:"cancel_hundler"})
		bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=language["mycab_menu"]["new_adress"]["save_text"],reply_markup=markup)
		return
	elif len(call.data.split(" ")) >= 2 and str(call.data.split(" ")[1]) == "nxt_ord_notsave":
		name = language["mycab_menu"]["new_adress"]["not_save_name"]
		if base.select_where("save_adress_base",{"user_id":int(call.from_user.id),"name":name}):
			base.delete("save_adress_base",user_id=int(call.from_user),name=name)
		fsm.set_state(call.message.chat.id,"cab_new_adress_get_glocation",next_order=True,name=name)
		bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=language["mycab_menu"]["new_adress"]["get_glocation"],reply_markup=markup)
		return
	elif len(call.data.split(" ")) >= 2 and str(call.data.split(" ")[1]) == "nxt_ord_save":
		next_order = True
	fsm.set_state(call.message.chat.id,"cab_new_adress_get_name",next_order=next_order)
	bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=language["mycab_menu"]["new_adress"]["get_name"],reply_markup=markup)



# ----Имя нового адресса забора----
@bot.message_handler(func=lambda message: fsm.get_state(message.from_user.id).state == "cab_new_adress_get_name")
@log
def cab_new_adress_get_name_update(message):
	language = language_check(message.from_user.id)
	args = fsm.get_state(message.from_user.id).args
	name = str(message.text)
	markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
	if base.select_where("save_adress_base",{"user_id":int(message.from_user.id),"name":name}):
		bot.send_message(message.chat.id,language["mycab_menu"]["new_adress"]["name_already_error"])
		return
	bot.send_message(message.chat.id,language["mycab_menu"]["new_adress"]["get_glocation"],reply_markup=markup)
	fsm.set_state(message.chat.id,"cab_new_adress_get_glocation",next_order=args.next_order,name=name)


# ----Локация нового адресса забора----
@bot.message_handler(content_types=['location', 'text'],func=lambda message: fsm.get_state(message.from_user.id).state == "cab_new_adress_get_glocation")
@log
def cab_new_adress_get_glocation_update(message):
	language = language_check(message.from_user.id)
	args = fsm.get_state(message.from_user.id).args
	markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
	if message.location:
		location = "cords_location {}:{}".format(message.location.latitude, message.location.longitude)
	else:
		location = str(message.text)
	bot.send_message(message.chat.id,language["mycab_menu"]["new_adress"]["get_owner_phone"],reply_markup=markup)
	fsm.set_state(message.chat.id,"cab_new_adress_get_owner_phone",next_order=args.next_order,name=args.name,location=location)


# ----Номер телефона для нового адресса забора----
@bot.message_handler(content_types=['location', 'text'],func=lambda message: fsm.get_state(message.from_user.id).state == "cab_new_adress_get_owner_phone")
@log
def cab_new_adress_get_phone_update(message):
	language = language_check(message.from_user.id)
	args = fsm.get_state(message.from_user.id).args
	markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
	bot.send_message(message.chat.id,language["mycab_menu"]["new_adress"]["get_owner_name"],reply_markup=markup)
	fsm.set_state(message.chat.id,"cab_new_adress_get_owner_name",next_order=args.next_order,name=args.name,location=args.location,phone=str(message.text))


# ---Имя овнера для нового адресса забора----
@bot.message_handler(content_types=['location', 'text'],func=lambda message: fsm.get_state(message.from_user.id).state == "cab_new_adress_get_owner_name")
@log
def cab_new_adress_get_owner_name_update(message):
	language = language_check(message.from_user.id)
	args = fsm.get_state(message.from_user.id).args
	insert_map = {
		"user_id":int(message.chat.id),
		"name":args.name,
		"get_location":args.location,
		"owner_phone":args.phone,
		"owner_name":str(message.text)}
	new_id = base.insert("save_adress_base",insert_map,return_id=True)
	if args.next_order:
		markup = tools.create_inlineKeyboard({language["new_order_menu"]["need_timing_menu"][0]:"new_order_timing {} 1".format(new_id),language["new_order_menu"]["need_timing_menu"][1]:"new_order_timing {} 0".format(new_id),language["cancel_hundler_but"]:"cancel_hundler"})
		bot.send_message(message.chat.id,language["new_order_menu"]["need_timing"],reply_markup=markup)
	else:
		bot.send_message(message.chat.id,language["mycab_menu"]["new_adress"]["ok"])










#####################--Платежи--################################################


# yandex 
'''

@bot.pre_checkout_query_handler(func=lambda query: True)
def checkout(pre_checkout_query):
	bot.answer_pre_checkout_query(pre_checkout_query.id, ok=True,error_message="Error. Try again...")





@bot.message_handler(content_types=['successful_payment'])
def got_payment(message):
	language = language_check(message.chat.id)
	payload = str(message.successful_payment.invoice_payload)
	price = float(message.successful_payment.total_amount) / 100
	if payload == "balans_up":
		current_balans = float(base.select_one("bot_user",user_id=int(message.chat.id))[3])
		base.update("bot_user",{"balans":current_balans+price},user_id=int(message.chat.id))
		bot.send_message(message.chat.id,language["mycab_menu"]["balans_up_ok"])
		base.insert("payments_history",{"user_id":int(message.chat.id),"amount":price,"do_name":"balans_up"})

'''




# ----Проверка оплаты----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split(" ")[0]) == "paid_check")
@log
def qiwi_paid_check_update(call):
	language = language_check(call.from_user.id)
	do_type = str(call.data.split(" ")[1])
	unic_id = str(call.data.split(" ")[2])
	pay_data = qiwi_pay.check_invoice(unic_id)
	if pay_data["status"]["value"] != "PAID":
		bot.answer_callback_query(callback_query_id=call.id,show_alert=False,text="NOT PAID ERROR...")
		return
	if do_type == "order":
		order_id = int(call.data.split(" ")[3])
		order_data = base.select_one("order_base",id=order_id)
		if not order_data:
			return
		order_data = get_order_by_data(order_data)
		base.update("order_base",{"state":"searthCurrier_online"},id=order_id)
		send_new_order_to_channel(cur_bot,language,order_data,config.ORDER_CURRIER_CHANNEL)
		bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=language["new_order_menu"]["payment_menu"]["ok"])
	elif do_type == "balans_up":
		price = float(pay_data["amount"]["value"])
		current_balans = float(base.select_one("bot_user",user_id=int(call.message.chat.id))[3])
		base.update("bot_user",{"balans":current_balans+price},user_id=int(call.message.chat.id))
		base.insert("payments_history",{"user_id":int(call.message.chat.id),"amount":price,"do_name":"balans_up"})
		bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=language["mycab_menu"]["balans_up_ok"])




#####################--Админ панель--################################################


# ----Обработка команды /apanel----
@bot.message_handler(commands=['apanel'])
def apanel_update(message):
	if not is_admin(message.chat.id):
		return
	language = language_check(message.chat.id)
	bot.send_message(message.chat.id,"Выберите действие:",reply_markup=menu.get_admin_panel(language))


# ----Меню рассылки----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split(" ")[0]) == "admin_mass_send_menu")
@log
def admin_mass_send_menu_update(call):
	language = language_check(call.from_user.id)
	markup = {
		"Курьерам":"admin_select_mass_send currier",
		"Пользователям":"admin_select_mass_send client",
		"Назад":"back_to_apanel"
	}
	bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text="Рассылка для?",reply_markup=tools.create_inlineKeyboard(markup))



# ----Вернуться в меню админки----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split(" ")[0]) == "back_to_apanel")
@log
def back_to_admin_update(call):
	language = language_check(call.from_user.id)
	bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text="Выберите действие:",reply_markup=menu.get_admin_panel(language))



# ----Рассылка для----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split(" ")[0]) == "admin_select_mass_send")
@log
def admin_mass_send_select_update(call):
	language = language_check(call.from_user.id)
	markup = tools.create_inlineKeyboard({language["cancel_hundler_but"]:"cancel_hundler"})
	sent_to = str(call.data.split(" ")[1])
	fsm.set_state(call.message.chat.id,"admin_mass_get_text",sent_to=sent_to)
	bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text="Отправьте сообщение для рассылки:",reply_markup=markup)


# ----Текст для рассылки----
@bot.message_handler(content_types=['text'],func=lambda message: fsm.get_state(message.from_user.id).state == "admin_mass_get_text")
@log
def admin_mass_send_get_text_update(message):
	language = language_check(message.from_user.id)
	args = fsm.get_state(message.from_user.id).args
	sent_to = str(args.sent_to)
	func = None
	send_list = []
	if sent_to == "currier":
		func = cur_bot.send_message
		send_list = base.select_all("currier_base")
	elif sent_to == "client":
		func = bot.send_message
		send_list = base.select_all("bot_user")
	counter = 0
	stoper = 0
	for user in send_list:
		if stoper >= 28:
			time.sleep(1)
			stoper = 0
		else:
			stoper += 1
		try:
			func(user[0],str(message.text))
			counter += 1
		except:
			pass
	bot.send_message(message.chat.id,"Успешно отправлено для: {}".format(counter))




# ----Заблокировать клиента----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split(" ")[0]) == "block_client_menu")
@log
def admin_block_client_menu_update(call):
	language = language_check(call.from_user.id)
	markup = {}
	for user in base.select_all("bot_user"):
		name = "{}({})".format(user[2],user[0])
		markup[name] = "admin_block client {}".format(user[0])
	markup["Назад"] = "back_to_apanel"
	bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text="Кого Заблокировать?",reply_markup=tools.create_inlineKeyboard(markup))


# ----Заблокировать куррьера----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split(" ")[0]) == "block_currier_menu")
@log
def admin_block_currier_menu_update(call):
	language = language_check(call.from_user.id)
	markup = {}
	for user in base.select_all("currier_base"):
		name = "{}({})".format(user[2],user[0])
		markup[name] = "admin_block currier {}".format(user[0])
	markup["Назад"] = "back_to_apanel"
	bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text="Кого Заблокировать?",reply_markup=tools.create_inlineKeyboard(markup))



# ----Заблокировать----
@bot.callback_query_handler(func=lambda call: True and str(call.data.split(" ")[0]) == "admin_block")
@log
def admin_bloack_select_update(call):
	language = language_check(call.from_user.id)
	block_type = str(call.data.split(" ")[1])
	user_id = int(call.data.split(" ")[2])
	if block_type == "client":
		base.insert("block_user",{"user_id":user_id})
	elif block_type == "currier":
		base.insert("block_currier",{"user_id":user_id})
	bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text="Успешно заблокировано!")






#####################--Общие функции--################################################


# ----Отменить хендлер----
@bot.callback_query_handler(func=lambda call: True and str(call.data) == "cancel_hundler")
@log
def cancel_hundler(call):
    language = language_check(call.from_user.id)
    fsm.remove_state(call.from_user.id)
    markup = False
    bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text=language["cancel_hundler_ok"],reply_markup=markup)



# ----Незарегистрированые сообщения----
@bot.message_handler(func=lambda message: True)
@log
def all_msg(message):
    print(" -> NOT REGISTER")

# ----Незарегистрированые кнопки----
@bot.callback_query_handler(func=lambda call: True)
@log
def all_callback(call):
    print(" -> NOT REGISTER")