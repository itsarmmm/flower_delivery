import requests
import json
from datetime import datetime,timedelta



def generate_time(hours):
    date = datetime.now()+timedelta(hours=hours)
    return date.strftime("%Y-%m-%dT%H:%M:%S+03:00")


class QiwiPay:
    def __init__(self,token,login,p2p_key=False,username=False):
        self.token = token
        self.login = login
        self.base_url = "https://edge.qiwi.com/"
        self.username = username
        self.p2p_key = p2p_key

    def make_request(self,method,param={},r_method="GET",q_token=False):
        token_to_use = self.token
        if q_token:
            token_to_use = q_token
        tmp_ses = requests.Session()
        tmp_ses.headers['Accept']= 'application/json'
        tmp_ses.headers['Authorization'] = 'Bearer ' + token_to_use
        tmp_ses.headers['Content-Type'] = 'application/json'
        if r_method == "GET":
            return tmp_ses.get(method,params=param)
        elif r_method == "PUT":
            return tmp_ses.put(method,params=param)

    def get_balans(self):
        method = self.base_url + f"funding-sources/v2/persons/{self.login}/accounts"
        balans = self.make_request(method)
        return balans.json()

    def get_main_balans(self):
        balans_data = self.get_balans()
        for i in balans_data["accounts"]:
            if i["defaultAccount"]:
                return i["balance"]["amount"]

    def get_last_payments_history(self,rows_num=5, next_TxnId='', next_TxnDate=''):
        method = self.base_url + f"/payment-history/v2/persons/{self.login}/payments"
        param = {'rows': rows_num, 'nextTxnId': next_TxnId, 'nextTxnDate': next_TxnDate}
        return self.make_request(method,param=param).json()["data"]

    def beautiful_latest(self,rows_num=5):
        data = self.get_last_payments_history(rows_num=rows_num)
        out = []
        for payments in data:
            out.append({"id":payments["txnId"],"type":payments["type"],"status":payments["status"],"amount":payments["total"]["amount"],"description":payments["comment"],"date":payments["date"]})
        return out

    def get_paylink(self,amount,pre_amount=0,comment=""):
        user_data = self.login
        user_data_type = "99"
        if self.username:
            user_data = self.username
            user_data_type = "99999"
        method = f"https://qiwi.com/payment/form/{user_data_type}?"
        parameters = {'amountInteger':str(amount),'amountFraction':str(pre_amount) ,'currency':'643',
        'extra[\'account\']':user_data,
              'extra[\'comment\']':comment}
        return self.make_request(method,param=parameters).url

    def create_invoice(self,unic_id,amount):
        if not self.p2p_key:
            return False
        headers={'Authorization': f'Bearer {self.p2p_key}','Accept': 'application/json','Content-Type': 'application/json'}
        params={'amount': {'value': amount, 
                           'currency': 'RUB',},
                'expirationDateTime': (datetime.now()+timedelta(hours=2)).strftime("%Y-%m-%dT%H:%M:%S+03:00"), 
                'customer': {}, 
                'customFields': {},}
        params = json.dumps(params)
        response = requests.put(f'https://api.qiwi.com/partner/bill/v1/bills/{unic_id}',headers=headers,data=params)
        if int(response.status_code) != 200:
            return False
        return response.json()



    def check_invoice(self,unic_id):
        if not self.p2p_key:
            return False
        headers={'Authorization': f'Bearer {self.p2p_key}','Accept': 'application/json','Content-Type': 'application/json'}
        params = {}
        return requests.get(f'https://api.qiwi.com/partner/bill/v1/bills/{unic_id}',headers=headers,data=params).json()


