from app import app
from flask_login import LoginManager, UserMixin, login_required, login_user, current_user
from flask import Flask, render_template, request, session, redirect,url_for,flash
import config



login_manager=LoginManager()
app.config['SECRET_KEY'] = "2bca96e01a1eea95a650d9d5320753a2fbd16bea984215cdf97ee"
login_manager.login_view = 'login'
login_manager.init_app(app)





class User(UserMixin):
    def __init__(self,login,password):
        self.login = login
        self.password = password


    def set_password(self, password):
        self.password = password

    def check_password(self):
        if str(self.password) == config.TOKEN:
            return True
        return False

    @property
    def is_authenticated(self):
        return True

    @property
    def is_active(self):
        return True

    @property
    def is_anonymous(self):
        return False

    def get_id(self):
        return self.login




@login_manager.user_loader
def load_user(user_id):
    return User(user_id,"")


@app.route('/test', methods=['GET'])
@login_required
def test():
    return "ok"




@app.route('/login', methods=['GET',"POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))

    if request.method == 'POST':
        username = request.form.get('login')
        password = request.form.get('password')
        print(username,password)    
        user = User(username,password)
        if user and user.check_password():
            login_user(user, remember=True)
            return redirect(url_for('index'))
        else:
            flash("Invalid data")
    return render_template('login.html')