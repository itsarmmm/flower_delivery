#from app import app
from lang_editor import app
from base_web import login_manager
from app import redis_connector,base
from flask import Flask, render_template, request, session, redirect,url_for,flash
from flask_login import LoginManager, UserMixin, login_required, login_user, current_user
from collections import namedtuple
from main import bot
from currier_bot import bot as c_bot
import json
import os
import telebot
import config
import time
import traceback


if config.DEBUG:
    import logging
    logging.basicConfig(level=logging.DEBUG)




@app.route('/', methods=['GET'])
@login_required
def index():
    current_data = redis_connector.option
    return render_template('index.html',upper_price=current_data["upperPrice"],need_garant=current_data["needGarant"],need_timing=current_data["needTiming"])



@app.route('/stat', methods=['GET'])
@login_required
def go_stat():
    return render_template('stat.html')


@app.route('/save_option', methods=['POST'])
def save_option():
    upperPrice = int(request.form.get('upperPrice'))
    needGarant = int(request.form.get('needGarant'))
    needTiming = int(request.form.get('needTiming'))
    if not(upperPrice and needGarant and needTiming):
        return redirect(url_for('index'))
    new = {"upperPrice":upperPrice,"needGarant":needGarant,"needTiming":needTiming}
    redis_connector.option = new
    flash("Успешно!")
    return redirect(url_for('index'))






class CurrierIncomeCard:
    def __init__(self,user_id,name,phone,snils,bank,bik,korespond_amount,raz_amount,inn,income_balans):
        self.user_id = user_id
        self.name = name
        self.phone = phone
        self.snils = snils
        self.bank = bank
        self.bik = bik
        self.korespond_amount = korespond_amount
        self.raz_amount = raz_amount
        self.inn = inn
        self.income_balans = income_balans






@app.route('/currier_income', methods=['GET'])
@login_required
def go_cincome():
    all_currier = base.select_all("currier_base")
    all = []
    for cur in all_currier:
        income_balans = float(cur[18])
        if income_balans >= 1:
            name = cur[2]
            phone = cur[16]
            inn = cur[15]
            raz_amount = cur[14]
            korespond_amount = cur[13]
            bik = cur[12]
            bank = cur[11]
            snils = cur[10]
            obj = CurrierIncomeCard(cur[0],name,phone,snils,bank,bik,korespond_amount,raz_amount,inn,income_balans)
            all.append(obj)
    
    return render_template('curincome.html',all=all)




@app.route('/curincome_to_null/<string:user_id>', methods=['GET'])
@login_required
def go_curincome_null(user_id):
    user_id = int(user_id)
    new = float(0)
    base.update("currier_base",{"income_balans":new},user_id=user_id)
    return redirect(url_for("go_cincome"))








# WEBHOOK

@app.route("/set_web")
def webhook():
    bot.remove_webhook()
    bot.set_webhook(url = str(config.DOMEN_HOST) +"bot_update/"+str(config.TOKEN))
    time.sleep(1)
    c_bot.remove_webhook()
    c_bot.set_webhook(url = str(config.DOMEN_HOST) +"bot_update/"+str(config.CURRIER_BOT_TOKEN))
    return "!", 200




@app.route('/bot_update/<string:get_token>', methods=['POST'])
def getMessage(get_token):
    try:
        if str(get_token) == str(config.TOKEN):
            bot.process_new_updates([telebot.types.Update.de_json(request.stream.read().decode("utf-8"))])
        elif str(get_token) == str(config.CURRIER_BOT_TOKEN):
            c_bot.process_new_updates([telebot.types.Update.de_json(request.stream.read().decode("utf-8"))])
        else:
            print("NOTP: ",get_token)
    except:
        error_info = str(traceback.format_exc())
        print(error_info)
    return "!", 200






if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get('PORT', 5000))) 