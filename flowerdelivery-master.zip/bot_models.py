

class Order:
    def __init__(self,id,user_id,state,get_location,owner_phone,owner_name,get_time,go_data,price,garant,packed_price,taiming_mode,comment,edit_text,currier_id,currier_display_price):
        self.id = id
        self.user_id = user_id
        self.state = state
        self.get_location = get_location
        self.owner_phone = owner_phone
        self.owner_name = owner_name
        self.get_time = get_time 
        self.go_data = go_data
        self.price = price
        self.garant = garant
        self.packed_price = packed_price
        self.taiming_mode = taiming_mode
        self.comment = comment
        self.edit_text = edit_text
        self.currier_id = currier_id
        self.currier_display_price = currier_display_price

    def __repr__(self):
        return "<Order(id={},user_id={},state={},get_location={},owner_phone={},owner_name={},get_time={},go_data={},price={},garant={},packed_price={},taiming_mode={},comment={},edit_text={})>".format( \
                self.id,self.user_id,self.state,self.get_location,self.owner_phone,self.owner_name,self.get_time,self.go_data,self.price,self.garant,self.packed_price,self.taiming_mode,self.comment,self.edit_text)





class OrderGoAdress:
    def __init__(self,location,phone,name,time):
        self.location = location
        self.phone = phone
        self.name = name
        self.time = time


    def __repr__(self):
        return "<OrderGoAdress(location={},phone={},name={},time={})>".format(self.location,self.phone,self.name,self.time)


