from main import bot
from currier_bot import bot as c_bot



CURREIR = False




if __name__ == "__main__":
	if CURREIR:
		c_bot.remove_webhook()
		c_bot.polling(True)
	else:	
		bot.remove_webhook()
		bot.polling(True)