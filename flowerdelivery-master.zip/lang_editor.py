import time
import re
from flask import Flask, request, render_template, jsonify, make_response,redirect,url_for
from wtforms import Form, BooleanField, HiddenField, TextField, TextAreaField, widgets, SelectMultipleField, RadioField
from flask_login import LoginManager, UserMixin, login_required, login_user, current_user
import hashlib
import re
import json
import os
import random
from collections import OrderedDict
from time import strftime
from app import base,redis_connector
from base_web import app,login_manager

from bot_middleware import language_check,init_redis


init_redis()


try:
    app_root = os.environ["EDWIN_BASE"]
except:
    app_root = "/app/edwin"




@app.route('/language_editor', methods=['GET', 'POST'])
@login_required
def go_language_editor():
    curval = loaddata(False)
    return render_template('lang_editor.html', curval=json.dumps(curval))



@app.route('/language_editor_save', methods=['POST'])
@login_required
def save_edwin():
    output = request.json
    j_out = json.loads(output) # object_pairs_hook=OrderedDict
    new = {"ru":j_out}
    redis_connector.lang = new
    curval = loaddata(False)
    return render_template('lang_editor.html', curval=json.dumps(curval))
    #return redirect(url_for('index'))




def fixdata(indata):

    u = indata
    u = u.replace("&lt;empty&gt;", "")
    u = u.replace("&gt;", ">")
    u = u.replace("&lt;", "<")
    return u


def savedata(jsonfile, jdata):
    retval = 0
    try:
        u = open(jsonfile, 'w')
        u.write(fixdata(json.dumps(jdata, sort_keys=False, indent=4, separators=(',', ': '))) + "\n")
        u.close()
    except:
        retval = 1
        print("Error saving json data to %s" % jsonfile)
    return retval



def loaddata(jsonfile):
    return language_check(False,get_template=False,get_current="ru")





