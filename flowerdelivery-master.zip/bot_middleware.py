import json
import config
import traceback
import pickle
import bot_models
import secrets
from app import sms_api
from random import choice
from app import base,redis_connector



def language_check(user_id,get_template=False,get_current="ru"):
    get = "ru"
    if get_current:
        get = get_current
    else:
        pass
    if get_template:
        with open(f"{get}.json",encoding="utf-8") as file:
            return json.load(file)
    else:
        return redis_connector.lang[get]





def get_percent_data():
    return redis_connector.option







def init_redis(reset=False,reset_option=False):
    if not redis_connector.lang or reset:
        current = language_check(False,get_template=True,get_current="ru")
        redis_connector.lang =  {"ru":current}
    if not redis_connector.option or reset_option:
        new = {"upperPrice":7,"needGarant":2,"needTiming":5}
        redis_connector.option = new
    return True




def send_confrim_code(phone,code_len=8):
    """Отправить на номер код подтверждения регистрации"""
    variable = list(range(1,10))
    code = "0"
    for i in range(1,code_len+1):
        code += str(choice(variable))
    try:
        status = sms_api.send(phone,config.SMS_TEMPLATES.format(code))
        if status["result"] != "accepted":
            return False
        return code
    except:
        return False


def send_sms(phone,sms_text):
    try:
        status = sms_api.send(phone,str(sms_text))
        if status["result"] != "accepted":
            return False
        return True
    except:
        return False






def to_base_binary_data(data):
    """Превратить обьект в байт обьект для записи в базу данных"""
    return base.to_binary(pickle.dumps(data))


def from_base_get_binary(data):
    """Превратить байт обьект из базы данных в первичное состояние"""
    return pickle.loads(data)



def get_order_by_data(data):
    """Получить обьект заказа из кортежа базы данных"""
    write_data = list(data)
    write_data[7] = from_base_get_binary(write_data[7])
    return bot_models.Order(*write_data)


def is_admin(user_id):
    admin_list = list(config.MAIN_ADMIN_LIST)
    for admin in base.select_all("admin_list"):
        admin_list.append(str(admin[0]))
    if str(user_id) in admin_list:
        return True
    return False


def generate_hash(hash_len=8):
    return str(secrets.token_hex(hash_len))





