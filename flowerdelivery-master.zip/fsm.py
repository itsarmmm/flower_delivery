import pickle
from collections import namedtuple

class State:
	def __init__(self,state,**args):
		self.state = state
		self.args = namedtuple("Args", args.keys())(*args.values())

	def __repr__(self):
		return "<State(state={}, args={})>".format(self.state,self.args)



class FSM:
	table = "user_state"
	def __init__(self,fsm_base):
		self.base = fsm_base
	
	def set_state(self,user_id,state,**arg):
		data = self.base.to_binary(pickle.dumps(arg))
		self.remove_state(user_id)
		sql = self.base.insert(self.table,{"user_id":int(user_id),"state":state,"args":data})


	def get_state(self,user_id,slice_format=False):
		try:
			get = self.base.select_one(self.table,user_id=int(user_id))
		except:
			get = False
		if get:
			arg = pickle.loads(get[2])
			state = str(get[1])
			if slice_format:
				return (state,arg)
			return State(state,**arg)
		else:
			if slice_format:
				return("emty",{})
			return State("emty",**{})


	def remove_state(self,user_id):
		self.base.delete(self.table,user_id=int(user_id))


class RedisFSM:
	def __init__(self,fsm_base):
		self.base = fsm_base




	def set_state(self,user_id,state,**arg):
		#data = pickle.dumps(arg)
		data = arg
		self.base[str(user_id)] = {"state":state,"args":data}


	def get_state(self,user_id,slice_format=False):
		get = self.base[str(user_id)]
		if get:
			get = (int(user_id),get["state"],get["args"])
		else:
			get = False

		if get:
			#arg = pickle.loads(get[2])
			arg = get[2]
			state = str(get[1])
			if slice_format:
				return (state,arg)
			return State(state,**arg)
		else:
			if slice_format:
				return("emty",{})
			return State("emty",**{})


	def remove_state(self,user_id):
		self.base[str(user_id)] = {"state":"emty","args":{}}



		